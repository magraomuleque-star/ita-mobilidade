#!/usr/bin/env bash
set -euo pipefail

START_DIR="$(pwd)"

# Se o ZIP tiver sido extraido dentro de uma subpasta unica, entra nela automaticamente
if [ ! -f "settings.gradle.kts" ]; then
  FOUND_SETTINGS="$(find . -maxdepth 2 -name "settings.gradle.kts" | head -n 1 || true)"
  if [ -n "$FOUND_SETTINGS" ]; then
    cd "$(dirname "$FOUND_SETTINGS")"
  else
    echo "ERRO: Arquivos do projeto Android nao encontrados nesta pasta."
    echo "Certifique-se de enviar e extrair o arquivo ZIP primeiro (ex: unzip *.zip)."
    exit 1
  fi
fi

echo ">>> Projeto ITA Mobilidade localizado em: $(pwd)"

# 1. Garantir Java JDK 21 (x86_64 Linux)
JAVA_MAJOR="0"
if command -v java >/dev/null 2>&1; then
  JAVA_MAJOR="$(java -version 2>&1 | head -n 1 | sed -E 's/.*"([0-9]+).*/\1/' || echo "0")"
fi

if [ "$JAVA_MAJOR" != "21" ]; then
  if [ ! -x "$HOME/.jdk21/bin/java" ]; then
    echo ">>> Baixando Java JDK 21 para compilacao Android..."
    mkdir -p "$HOME/.jdk21"
    curl -fsSL "https://api.adoptium.net/v3/binary/latest/21/ga/linux/x64/jdk/hotspot/normal/eclipse" -o /tmp/jdk21.tar.gz
    tar -xzf /tmp/jdk21.tar.gz -C "$HOME/.jdk21" --strip-components=1
    rm -f /tmp/jdk21.tar.gz
  fi
  export JAVA_HOME="$HOME/.jdk21"
  export PATH="$JAVA_HOME/bin:$PATH"
fi

# 2. Garantir Android SDK e aceite das licencas
if [ -z "${ANDROID_SDK_ROOT:-}" ] && [ -z "${ANDROID_HOME:-}" ]; then
  export ANDROID_SDK_ROOT="$HOME/android-sdk"
  export ANDROID_HOME="$HOME/android-sdk"
else
  export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
  export ANDROID_HOME="$ANDROID_SDK_ROOT"
fi

if [ ! -x "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo ">>> Configurando Android SDK Command-line Tools..."
  mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
  curl -fsSL "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o /tmp/cmdline-tools.zip
  rm -rf /tmp/cmdline-extract
  unzip -q -o /tmp/cmdline-tools.zip -d /tmp/cmdline-extract
  rm -rf "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  mv /tmp/cmdline-extract/cmdline-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  rm -rf /tmp/cmdline-tools.zip /tmp/cmdline-extract
fi

export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"
echo ">>> Aceitando licencas oficiais do Android SDK..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true

# 3. Garantir Gradle 9.3.1
GRADLE_BIN="gradle"
if ! command -v gradle >/dev/null 2>&1 || ! gradle --version 2>/dev/null | grep -q "9.3.1"; then
  if [ ! -x "$HOME/.gradle-dist/gradle-9.3.1/bin/gradle" ]; then
    echo ">>> Baixando Gradle 9.3.1..."
    mkdir -p "$HOME/.gradle-dist"
    curl -fsSL "https://services.gradle.org/distributions/gradle-9.3.1-bin.zip" -o /tmp/gradle-9.3.1.zip
    unzip -q -o /tmp/gradle-9.3.1.zip -d "$HOME/.gradle-dist"
    rm -f /tmp/gradle-9.3.1.zip
  fi
  GRADLE_BIN="$HOME/.gradle-dist/gradle-9.3.1/bin/gradle"
fi

# 4. Restaurar debug.keystore registrado no Firebase (Login Google + Firestore)
if [ ! -f "debug.keystore" ] && [ -f "debug.keystore.base64" ]; then
  echo ">>> Restaurando certificado debug.keystore vinculado ao Firebase..."
  base64 -d debug.keystore.base64 > debug.keystore
fi

# 5. Compilar o APK instalavel
echo ">>> Compilando APK do ITA Mobilidade (aguarde de 2 a 4 minutos na primeira vez)..."
"$GRADLE_BIN" :app:assembleDebug --no-daemon

cp -f app/build/outputs/apk/debug/app-debug.apk "$START_DIR/ITA-Mobilidade-debug.apk"

echo ""
echo "================================================================"
echo "CONCLUIDO COM SUCESSO!"
echo "Arquivo gerado: ITA-Mobilidade-debug.apk"
echo "No menu lateral de arquivos da nuvem, toque e segure em"
echo "'ITA-Mobilidade-debug.apk' e selecione 'Download' para baixar!"
echo "================================================================"
