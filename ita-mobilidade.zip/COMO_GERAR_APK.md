# Guia de Exportação e Geração do APK — ITA Mobilidade

O projeto **ITA Mobilidade** (`com.aistudio.itamobilidade.vrkxqp`) é um **aplicativo Android 100% nativo** desenvolvido em **Kotlin + Jetpack Compose**, com ícone adaptativo próprio, modos **Passageiro** e **Motorista**, e integração real com **Firebase Authentication** e **Cloud Firestore**.

---

## 1. Gerar / Baixar o APK Diretamente no Google AI Studio

As variáveis opcionais futuras em `.env.example` foram deixadas comentadas por padrão para **não bloquear nem restringir** o download/compartilhamento do APK na plataforma:

1. No navegador do celular (Chrome), se algum botão do topo estiver oculto pela tela estreita, toque no menu **`⋮`** do navegador e marque **Para computador (Versão para computador)**.
2. Na barra superior do **Google AI Studio**, toque no ícone de **Configurações (⚙️) / Exportar / Download**.
3. Caso a opção **Download APK / Generate APK** apareça disponível na sua conta, toque nela para baixar o instalador `.apk` diretamente no celular.
4. Abra o arquivo baixado pelo app **Arquivos (Files)** do Android e toque em **Instalar** (permitindo instalar apps desta fonte, se solicitado).

---

## 2. Exportar e Compilar 100% pelo Celular Android (Sem Computador — GitHub Actions)

Se o botão direto de APK não aparecer no seu navegador móvel, você pode exportar e compilar o projeto nativo usando **apenas o celular Android**, sem perder nenhum arquivo nem a conexão com o Firebase:

1. **Exporte sem perder o projeto:** Na barra superior do **Google AI Studio**, toque em **Export / Push to GitHub** (Enviar para o GitHub). O projeto atual permanece salvo no seu histórico do AI Studio e uma cópia completa é enviada para um repositório na sua conta GitHub (recomendado escolher repositório **Privado**).
2. **Compilação automática na nuvem:** Assim que o envio terminar, abra `github.com/<seu-usuario>/<nome-do-repositorio>` no navegador do celular. O arquivo `.github/workflows/build-apk.yml` já incluído no projeto inicia automaticamente a compilação Android nativa na aba **Actions** (leva de 2 a 4 minutos, usando Java 21 + Android SDK + Gradle 9.3.1).
   - *Observação:* Se precisar iniciar manualmente, abra a aba **Actions → Gerar APK - ITA Mobilidade → Run workflow**.
3. **Baixe o APK pronto no celular:** Quando a execução ficar com o ícone verde de concluído:
   - Na página inicial do repositório no GitHub, toque em **Releases** e toque em **`ITA-Mobilidade-debug.apk`** para baixar o APK direto no celular; **ou**
   - Na execução concluída da aba **Actions**, role até **Artifacts**, baixe **`ITA-Mobilidade-APK`**, extraia o `.zip` no app **Arquivos** do Android e toque em **`ITA-Mobilidade-debug.apk`**.
4. **Instale no Android:** Toque no arquivo `.apk` baixado e confirme a instalação. Como o fluxo restaura automaticamente o `debug.keystore.base64` original, o APK já vem assinado com o certificado SHA-1 registrado no Firebase (`CF:6D:2B:3B:95:C5:F4:AD:97:D0:EC:76:1E:E9:EA:65:42:8F:EC:71`), mantendo o **Login com Google** e o **Cloud Firestore** funcionando imediatamente no aparelho real.

> **Por que usar GitHub Actions no celular em vez de apps locais como Termux/AndroidIDE?**
> O projeto utiliza **Android Gradle Plugin 9.1.1, Gradle 9.3.1 e SDK 36**, cujas ferramentas oficiais do Android SDK (`aapt2`) exigem arquitetura `x86_64` (servidor/PC), enquanto celulares Android usam processadores `ARM64`. Compilar na nuvem via GitHub Actions é gratuito, leva ~3 minutos pelo próprio navegador do celular e preserva 100% do código nativo.

---

## 3. Exportar ZIP para Computador (Backup Completo / Android Studio)

1. Na barra superior do **Google AI Studio**, escolha **Download / Export ZIP** para guardar uma cópia completa de todos os arquivos no celular ou computador (seu projeto continua salvo normalmente no AI Studio).
2. No computador (com JDK 21 + Android Studio ou Gradle 9.3.1), extraia o ZIP e restaure a chave registrada no Firebase:
   ```bash
   base64 -d debug.keystore.base64 > debug.keystore
   ```
3. Execute `gradle :app:assembleDebug` ou use **Build → Build Bundle(s) / APK(s) → Build APK(s)** no Android Studio para gerar `app/build/outputs/apk/debug/app-debug.apk`.
