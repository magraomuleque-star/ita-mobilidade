const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const PASSENGER_UID = "passenger_ana_01";
const OTHER_PASSENGER_UID = "passenger_bruno_02";
const DRIVER_UID = "driver_carlos_01";
const OTHER_DRIVER_UID = "driver_diego_02";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function serverTs() {
  return new Date(Date.now() - 1000);
}

async function seedPassengerAndDriver({ driverOnline = true } = {}) {
  const ts = new Date(Date.now() - 5000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("passengers").doc(PASSENGER_UID).set({
      userId: PASSENGER_UID,
      fullName: "Ana Paula Silva",
      email: "ana@exemplo.com",
      phone: "11999991111",
      createdAt: ts,
      updatedAt: ts,
    });
    await db.collection("drivers").doc(DRIVER_UID).set({
      driverId: DRIVER_UID,
      fullName: "Carlos Motoboy",
      email: "carlos@exemplo.com",
      phone: "11988882222",
      vehicleModel: "Honda CG 160 Vermelha",
      vehiclePlate: "BRA2E19",
      online: driverOnline,
      createdAt: ts,
      updatedAt: ts,
    });
  });
}

function validOrderPayload(ts) {
  return {
    passengerId: PASSENGER_UID,
    passengerName: "Ana Paula Silva",
    serviceType: "CORRIDA_MOTO",
    originAddress: "Praça Central, 100 - Centro",
    destinationAddress: "Terminal Rodoviário, 450",
    originLat: -23.201,
    originLng: -45.889,
    destLat: -23.185,
    destLng: -45.872,
    packageDescription: "",
    recipientName: "",
    paymentMethod: "PIX",
    paymentStatus: "AGUARDANDO_PROVEDOR_PIX",
    estimatedDistanceKm: 4.2,
    priceCents: 1250,
    status: "SOLICITADO",
    driverId: "",
    driverName: "",
    driverVehicleModel: "",
    driverVehiclePlate: "",
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Unauthenticated user cannot read or create profiles or orders", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("orders").where("status", "==", "SOLICITADO").get());
  await assertFails(unauthDb.collection("passengers").doc(PASSENGER_UID).get());
  await assertFails(unauthDb.collection("drivers").doc(DRIVER_UID).get());
});

test("Profile separation & PII isolation: passenger cannot register as driver or read other profiles", async () => {
  await seedPassengerAndDriver();
  const anaDb = testEnv.authenticatedContext(PASSENGER_UID).firestore();
  const carlosDb = testEnv.authenticatedContext(DRIVER_UID).firestore();
  const ts = serverTs();

  // Owner can read own profile
  await assertSucceeds(anaDb.collection("passengers").doc(PASSENGER_UID).get());
  await assertSucceeds(carlosDb.collection("drivers").doc(DRIVER_UID).get());

  // Cross-user PII read and write blocked
  await assertFails(carlosDb.collection("passengers").doc(PASSENGER_UID).get());
  await assertFails(anaDb.collection("drivers").doc(DRIVER_UID).get());
  await assertFails(
    carlosDb.collection("drivers").doc(PASSENGER_UID).set({
      driverId: PASSENGER_UID,
      fullName: "Impostor",
      email: "carlos@exemplo.com",
      phone: "11999991111",
      vehicleModel: "Yamaha Factor 150",
      vehiclePlate: "ABC1D23",
      online: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // User can also maintain a separate driver profile under their own UID,
  // edit both profiles safely, and STILL cannot accept their own passenger order
  await assertSucceeds(
    anaDb.collection("drivers").doc(PASSENGER_UID).set({
      driverId: PASSENGER_UID,
      fullName: "Ana Paula Silva",
      email: "ana@exemplo.com",
      phone: "11999991111",
      vehicleModel: "Yamaha Factor 150",
      vehiclePlate: "ABC1D23",
      online: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    anaDb.collection("orders").doc("self_order_01").set(validOrderPayload(serverTs()))
  );
  await assertFails(
    anaDb.collection("orders").doc("self_order_01").update({
      status: "ACEITO",
      driverId: PASSENGER_UID,
      driverName: "Ana Paula Silva",
      driverVehicleModel: "Yamaha Factor 150",
      driverVehiclePlate: "ABC1D23",
      updatedAt: serverTs(),
    })
  );
});

test("Shadow update with ghost field is rejected on profile and order", async () => {
  await seedPassengerAndDriver();
  const anaDb = testEnv.authenticatedContext(PASSENGER_UID).firestore();
  const ts = serverTs();

  await assertFails(
    anaDb.collection("passengers").doc(PASSENGER_UID).update({
      fullName: "Ana Atualizada",
      isVerifiedAdmin: true,
      updatedAt: ts,
    })
  );

  await assertFails(
    anaDb.collection("orders").doc("order_ghost").set({
      ...validOrderPayload(ts),
      bonusFlag: true,
    })
  );
});

test("Full real-time order lifecycle: create -> accept (online only) -> en route -> in progress -> completed -> terminal lock", async () => {
  await seedPassengerAndDriver({ driverOnline: false });
  const anaDb = testEnv.authenticatedContext(PASSENGER_UID).firestore();
  const carlosDb = testEnv.authenticatedContext(DRIVER_UID).firestore();
  const otherDriverDb = testEnv.authenticatedContext(OTHER_DRIVER_UID).firestore();

  // 1. Registered passenger creates order
  await assertSucceeds(
    anaDb.collection("orders").doc("order_01").set(validOrderPayload(serverTs()))
  );

  // 2. Offline driver CANNOT accept order
  await assertFails(
    carlosDb.collection("orders").doc("order_01").update({
      status: "ACEITO",
      driverId: DRIVER_UID,
      driverName: "Carlos Motoboy",
      driverVehicleModel: "Honda CG 160 Vermelha",
      driverVehiclePlate: "BRA2E19",
      updatedAt: serverTs(),
    })
  );

  // 3. Driver goes online
  await assertSucceeds(
    carlosDb.collection("drivers").doc(DRIVER_UID).update({
      online: true,
      updatedAt: serverTs(),
    })
  );

  // 4. Online driver accepts order
  await assertSucceeds(
    carlosDb.collection("orders").doc("order_01").update({
      status: "ACEITO",
      driverId: DRIVER_UID,
      driverName: "Carlos Motoboy",
      driverVehicleModel: "Honda CG 160 Vermelha",
      driverVehiclePlate: "BRA2E19",
      updatedAt: serverTs(),
    })
  );

  // 5. Unrelated third user cannot read accepted order
  await assertFails(otherDriverDb.collection("orders").doc("order_01").get());

  // 6. State shortcutting (ACEITO -> CONCLUIDO directly) is blocked
  await assertFails(
    carlosDb.collection("orders").doc("order_01").update({
      status: "CONCLUIDO",
      paymentStatus: "CONCLUIDO_PRESENCIAL",
      updatedAt: serverTs(),
    })
  );

  // 7. Step-by-step progression: ACEITO -> A_CAMINHO -> EM_ANDAMENTO -> CONCLUIDO
  await assertSucceeds(
    carlosDb.collection("orders").doc("order_01").update({
      status: "A_CAMINHO",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    carlosDb.collection("orders").doc("order_01").update({
      status: "EM_ANDAMENTO",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    carlosDb.collection("orders").doc("order_01").update({
      status: "CONCLUIDO",
      paymentStatus: "CONCLUIDO_PRESENCIAL",
      updatedAt: serverTs(),
    })
  );

  // 8. Terminal state lock: cannot mutate CONCLUIDO order
  await assertFails(
    carlosDb.collection("orders").doc("order_01").update({
      status: "EM_ANDAMENTO",
      updatedAt: serverTs(),
    })
  );
});

test("Client query alignment: filtered queries succeed, unfiltered orders list fails", async () => {
  await seedPassengerAndDriver({ driverOnline: true });
  const anaDb = testEnv.authenticatedContext(PASSENGER_UID).firestore();
  const carlosDb = testEnv.authenticatedContext(DRIVER_UID).firestore();

  await assertSucceeds(
    anaDb.collection("orders").doc("order_q1").set(validOrderPayload(serverTs()))
  );

  // Filtered queries aligned with rules succeed for authorized roles
  await assertSucceeds(anaDb.collection("orders").where("passengerId", "==", PASSENGER_UID).get());
  await assertSucceeds(carlosDb.collection("orders").where("status", "==", "SOLICITADO").get());
  await assertSucceeds(carlosDb.collection("orders").where("driverId", "==", DRIVER_UID).get());

  // Non-driver passenger CANNOT list open SOLICITADO orders of other passengers
  const brunoOnlyPassengerDb = testEnv.authenticatedContext(OTHER_PASSENGER_UID).firestore();
  await assertFails(
    brunoOnlyPassengerDb.collection("orders").where("status", "==", "SOLICITADO").get()
  );

  // Unfiltered query rejected (rules are not filters)
  await assertFails(anaDb.collection("orders").get());
});

test("Driver can record declined order in own declined_orders subcollection", async () => {
  await seedPassengerAndDriver({ driverOnline: true });
  const anaDb = testEnv.authenticatedContext(PASSENGER_UID).firestore();
  const carlosDb = testEnv.authenticatedContext(DRIVER_UID).firestore();

  await assertSucceeds(
    anaDb.collection("orders").doc("order_dec_1").set(validOrderPayload(serverTs()))
  );

  await assertSucceeds(
    carlosDb
      .collection("drivers")
      .doc(DRIVER_UID)
      .collection("declined_orders")
      .doc("order_dec_1")
      .set({
        driverId: DRIVER_UID,
        orderId: "order_dec_1",
        createdAt: serverTs(),
      })
  );

  await assertSucceeds(
    carlosDb.collection("drivers").doc(DRIVER_UID).collection("declined_orders").get()
  );
});
