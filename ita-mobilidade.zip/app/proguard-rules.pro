# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

-keepattributes SourceFile,LineNumberTable
-keepattributes Signature, *Annotation*

# Preserve Firestore data models (reflection-based .toObject() / .toObjects())
-keep class com.example.data.model.** { *; }

# Preserve Retrofit & Moshi payment gateway contracts and DTOs
-keep class com.example.data.payment.** { *; }
-keep interface com.example.data.payment.** { *; }

# Preserve BuildConfig fields for optional Secrets Gradle Plugin keys
-keep class com.example.BuildConfig { *; }


