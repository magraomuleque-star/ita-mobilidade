package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.DriverProfile
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.ServiceType
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ItaMobilityRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun fullPassengerAndDriverRealtimeOrderFlow_succeedsEndToEnd() = runBlocking {
    val runTag = UUID.randomUUID().toString().take(8)
    val passengerEmail = "passageira_$runTag@test.com"
    val driverEmail = "motorista_$runTag@test.com"
    val repo = ItaMobilityRepository(firestore, auth)

    // 1. Passageiro se cadastra e solicita entrega de pacote
    val passengerUid = signInTestUser(passengerEmail)
    val regPass =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.registerPassenger(fullName = "Mariana Costa", phone = "12991234567")
      }
    assertTrue("Cadastro passageiro deve ter sucesso: ${regPass.exceptionOrNull()}", regPass.isSuccess)

    val createResult =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.createOrder(
          passengerName = "Mariana Costa",
          serviceType = ServiceType.ENTREGA_PACOTE,
          originAddress = "Av. Dr. Nelson D'Ávila, 300 - Centro",
          destinationAddress = "Praça Marechal-do-Ar Eduardo Gomes, 50 - Vila das Acácias",
          originLat = -23.1931,
          originLng = -45.8872,
          destLat = -23.2087,
          destLng = -45.8769,
          packageDescription = "Caixa pequena com protótipo eletrônico",
          recipientName = "Prof. Henrique",
          paymentMethod = PaymentMethod.PIX,
          estimatedDistanceKm = 3.8,
          priceCents = 1650L,
        )
      }
    assertTrue("Criação do pedido deve funcionar: ${createResult.exceptionOrNull()}", createResult.isSuccess)
    val orderId = createResult.getOrThrow()

    // 2. Motorista se cadastra (inicia offline) e tenta aceitar -> deve falhar enquanto offline
    val driverUid = signInTestUser(driverEmail)
    val regDriver =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.registerDriver(
          fullName = "Rafael Motociclista",
          phone = "12988776655",
          vehicleModel = "Honda CG 160 Titan Preta",
          vehiclePlate = "ITA2A26",
        )
      }
    assertTrue("Cadastro motorista deve funcionar: ${regDriver.exceptionOrNull()}", regDriver.isSuccess)

    val driverProfileSnap = DriverProfile(
      driverId = driverUid,
      fullName = "Rafael Motociclista",
      vehicleModel = "Honda CG 160 Titan Preta",
      vehiclePlate = "ITA2A26",
      online = false,
    )
    val offlineAccept =
      withTimeout(DEFAULT_TIMEOUT_MS) { repo.acceptOrder(orderId, driverProfileSnap) }
    assertTrue("Motorista offline não pode aceitar pedido", offlineAccept.isFailure)

    // 3. Motorista fica ONLINE, recebe pedido na fila em tempo real e aceita
    val goOnline = withTimeout(DEFAULT_TIMEOUT_MS) { repo.setDriverOnlineStatus(true) }
    assertTrue(goOnline.isSuccess)

    val openOrders =
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeOpenOrdersForDriver().first { list -> list.any { it.id == orderId } }
      }
    assertTrue(openOrders.any { it.id == orderId })

    val onlineAccept =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.acceptOrder(orderId, driverProfileSnap.copy(online = true))
      }
    assertTrue("Motorista online deve aceitar pedido: ${onlineAccept.exceptionOrNull()}", onlineAccept.isSuccess)

    // 4. Motorista avança status: ACEITO -> A_CAMINHO -> EM_ANDAMENTO -> CONCLUIDO
    assertTrue(
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.advanceOrderStatus(orderId, OrderStatus.A_CAMINHO)
      }.isSuccess
    )
    assertTrue(
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.advanceOrderStatus(orderId, OrderStatus.EM_ANDAMENTO)
      }.isSuccess
    )
    assertTrue(
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.advanceOrderStatus(orderId, OrderStatus.CONCLUIDO)
      }.isSuccess
    )

    // 5. Passageiro visualiza o pedido concluído e dados do motorista em seu histórico
    signInTestUser(passengerEmail)
    val passengerOrders =
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observePassengerOrders(passengerUid).first { list ->
          list.any { it.id == orderId && it.status == OrderStatus.CONCLUIDO.code }
        }
      }
    val completed = passengerOrders.first { it.id == orderId }
    assertEquals("Rafael Motociclista", completed.driverName)
    assertEquals("ITA2A26", completed.driverVehiclePlate)
  }

  @Test
  fun crossUserProfileRead_andUnauthenticatedQuery_failWithPermissionDenied() = runBlocking {
    val runTag = UUID.randomUUID().toString().take(8)
    val aliceUid = signInTestUser("alice_$runTag@test.com")
    val repo = ItaMobilityRepository(firestore, auth)

    assertTrue(
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.registerPassenger("Alice Oliveira", "11998887777")
      }.isSuccess
    )

    // Bob tenta ler o perfil privado de Alice -> deve falhar com PERMISSION_DENIED
    signInTestUser("bob_$runTag@test.com")
    val crossRead = withTimeout(DEFAULT_TIMEOUT_MS) { repo.getPassengerById(aliceUid) }
    assertTrue(crossRead.isFailure)
    val crossEx = crossRead.exceptionOrNull()?.unwrapFirestoreException()
    assertNotNull(crossEx)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, crossEx?.code)

    // Usuário deslogado tenta escutar pedidos -> deve falhar com PERMISSION_DENIED
    auth.signOut()
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observePassengerOrders(aliceUid).first() }
      fail("Deveria lançar exceção para usuário não autenticado")
    } catch (e: Exception) {
      val firestoreEx = e.unwrapFirestoreException()
      assertNotNull("Esperava FirebaseFirestoreException aninhada, recebeu: $e", firestoreEx)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }
  }

  @Test
  fun profileUpdates_dualProfiles_andNonDriverListRejection_enforceRules() = runBlocking {
    val runTag = UUID.randomUUID().toString().take(8)
    val repo = ItaMobilityRepository(firestore, auth)

    // 1. Usuário cadastra e atualiza perfil de Passageiro, depois também cadastra perfil separado de Motorista
    val dualUid = signInTestUser("dual_$runTag@test.com")
    assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { repo.registerPassenger("Lucas Mendes", "12991112222") }.isSuccess)
    assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { repo.updatePassengerProfile("Lucas M. Silva", "12993334444") }.isSuccess)
    assertTrue(
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.registerDriver("Lucas M. Silva", "12993334444", "Yamaha Fazer 150 Azul", "SJC9F88")
      }.isSuccess
    )
    assertTrue(
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.updateDriverProfile("Lucas M. Silva", "12993334444", "Yamaha Fazer 150 Preta", "SJC9F88")
      }.isSuccess
    )

    val profiles =
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeUserProfiles(dualUid).first { it.passenger != null && it.driver != null }
      }
    assertEquals("Lucas M. Silva", profiles.passenger?.fullName)
    assertEquals("Yamaha Fazer 150 Preta", profiles.driver?.vehicleModel)

    // 2. Passageiro exclusivo (sem perfil em /drivers) NÃO pode listar pedidos SOLICITADO de terceiros
    signInTestUser("only_pass_$runTag@test.com")
    assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { repo.registerPassenger("Apenas Passageiro", "12995556666") }.isSuccess)
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observeOpenOrdersForDriver().first() }
      fail("Passageiro sem perfil de motorista não deve listar chamados abertos")
    } catch (e: Exception) {
      val firestoreEx = e.unwrapFirestoreException()
      assertNotNull(firestoreEx)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }
  }

  private companion object {
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 4000L
  }
}
