package com.example

import androidx.compose.ui.test.assertHasClickAction
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextReplacement
import com.example.data.repository.LocalInteractiveSessionDataSource
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w412dp-h915dp")
class MainActivityInteractionTest {

  @get:Rule val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Before
  fun setUp() {
    LocalInteractiveSessionDataSource.shared.resetForTesting()
  }

  @Test
  fun homeScreen_passengerDriverAndGoogleButtons_areDisplayedAndClickable() {
    composeTestRule.waitForIdle()

    composeTestRule
      .onNodeWithTag("home_passenger_button")
      .performScrollTo()
      .assertIsDisplayed()
      .assertHasClickAction()

    composeTestRule
      .onNodeWithTag("home_driver_button")
      .performScrollTo()
      .assertIsDisplayed()
      .assertHasClickAction()

    composeTestRule
      .onNodeWithTag("google_sign_in_button")
      .performScrollTo()
      .assertIsDisplayed()
      .assertHasClickAction()
  }

  @Test
  fun passengerToDriverEndToEnd_requestRideNavigateBackGoOnlineAcceptAndComplete() {
    composeTestRule.waitForIdle()

    // 1. Tap Passageiro on Home screen -> opens PassengerHomeScreen
    composeTestRule.onNodeWithTag("home_passenger_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("passenger_home_screen").assertIsDisplayed()

    // 2. Fill out motorcycle ride form and submit
    composeTestRule
      .onNodeWithTag("origin_input")
      .performScrollTo()
      .performTextReplacement("Praça Afonso Pena, 120 - Centro")
    composeTestRule
      .onNodeWithTag("destination_input")
      .performScrollTo()
      .performTextReplacement("Portaria Principal ITA")
    composeTestRule.onNodeWithTag("submit_order_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    // Verify order is active on Pedido Atual tab
    composeTestRule.onNodeWithTag("order_status_stepper").performScrollTo().assertIsDisplayed()

    // 3. Tap Voltar button in TopAppBar -> returns to Home screen
    composeTestRule.onNodeWithTag("navigate_back_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("home_auth_screen").assertIsDisplayed()

    // 4. Tap Motorista on Home screen -> opens DriverHomeScreen
    composeTestRule.onNodeWithTag("home_driver_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("driver_home_screen").assertIsDisplayed()

    // 5. Go online and accept the incoming order
    composeTestRule.onNodeWithTag("driver_go_online_cta").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("driver_incoming_orders_list").assertIsDisplayed()
    composeTestRule.onNodeWithText("Aceitar pedido").performClick()
    composeTestRule.waitForIdle()

    // 6. Advance order status: ACEITO -> A_CAMINHO -> EM_ANDAMENTO -> CONCLUIDO
    composeTestRule.onNodeWithTag("driver_advance_status_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("driver_advance_status_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("driver_advance_status_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    // 7. Verify earnings summary reflects completed ride
    composeTestRule.onNodeWithTag("driver_tab_earnings").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Serviços concluídos: 1").assertIsDisplayed()
  }

  @Test
  fun packageDeliveryForm_submitsPackageDetailsAndNavigatesToActiveTab() {
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("home_passenger_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("select_service_package").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    composeTestRule
      .onNodeWithTag("origin_input")
      .performScrollTo()
      .performTextReplacement("Av. Nelson D'Ávila, 400")
    composeTestRule
      .onNodeWithTag("destination_input")
      .performScrollTo()
      .performTextReplacement("Alojamento H8 - ITA")
    composeTestRule
      .onNodeWithTag("package_description_input")
      .performScrollTo()
      .performTextReplacement("Envelope de documentos acadêmicos")
    composeTestRule
      .onNodeWithTag("recipient_name_input")
      .performScrollTo()
      .performTextReplacement("Prof. Carlos")
    composeTestRule.onNodeWithTag("payment_chip_dinheiro").performScrollTo().performClick()
    composeTestRule.onNodeWithTag("submit_order_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("order_status_stepper").performScrollTo().assertIsDisplayed()
    composeTestRule
      .onNodeWithText("Pacote: Envelope de documentos acadêmicos • Destinatário: Prof. Carlos")
      .performScrollTo()
      .assertIsDisplayed()
  }

  @Test
  fun googleSignInButton_withoutConfiguredProviderInPreview_displaysClearMessageDialog() {
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("google_sign_in_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("google_auth_feedback_dialog").assertIsDisplayed()
    composeTestRule.onNodeWithTag("close_google_auth_dialog_button").performClick()
    composeTestRule.waitForIdle()
  }
}
