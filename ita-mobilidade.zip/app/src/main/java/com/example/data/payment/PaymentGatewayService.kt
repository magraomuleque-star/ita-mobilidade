package com.example.data.payment

import com.example.BuildConfig
import com.example.data.model.PaymentMethod
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

@JsonClass(generateAdapter = true)
data class PixChargeRequest(
  val orderId: String,
  val amountCents: Long,
  val payerName: String,
  val description: String,
)

@JsonClass(generateAdapter = true)
data class PixChargeResponse(
  val transactionId: String,
  val qrCodePayload: String,
  val expiresAtIso: String,
)

@JsonClass(generateAdapter = true)
data class CardPaymentIntentRequest(
  val orderId: String,
  val amountCents: Long,
  val currency: String = "BRL",
)

@JsonClass(generateAdapter = true)
data class CardPaymentIntentResponse(
  val intentId: String,
  val clientSecret: String,
)

/**
 * Contrato REST preparado para integração com backend/provedor de pagamentos
 * (ex.: Mercado Pago, Asaas, Pagar.me ou Stripe).
 * Nenhuma cobrança financeira é simulada localmente.
 */
interface PaymentProviderApi {
  @POST("v1/payments/pix")
  suspend fun createPixCharge(
    @Header("Authorization") bearerKey: String,
    @Body request: PixChargeRequest,
  ): PixChargeResponse

  @POST("v1/payments/card-intents")
  suspend fun createCardPaymentIntent(
    @Header("Authorization") bearerKey: String,
    @Body request: CardPaymentIntentRequest,
  ): CardPaymentIntentResponse
}

data class PaymentMethodNotice(
  val method: PaymentMethod,
  val isOnlineProviderConfigured: Boolean,
  val badgeLabelPtBr: String,
  val explanationPtBr: String,
)

object PaymentGatewayService {
  private const val PLACEHOLDER_PUBLIC_KEY = "YOUR_PAYMENT_PROVIDER_PUBLIC_KEY"

  // URL pública base configurável quando o backend do provedor estiver publicado
  const val DEFAULT_BACKEND_BASE_URL = "https://api-pagamentos-configuravel.itamobilidade.app/"

  private fun readOptionalProviderKey(): String {
    return runCatching {
        BuildConfig::class.java.getDeclaredField("PAYMENT_PROVIDER_PUBLIC_KEY").get(null) as? String
          ?: ""
      }
      .getOrDefault("")
      .trim()
  }

  val isProviderKeyConfigured: Boolean
    get() {
      val key = readOptionalProviderKey()
      return key.isNotEmpty() && key != PLACEHOLDER_PUBLIC_KEY
    }

  fun createPreparedRetrofitClient(baseUrl: String = DEFAULT_BACKEND_BASE_URL): PaymentProviderApi {
    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    val client = OkHttpClient.Builder().build()
    return Retrofit.Builder()
      .baseUrl(baseUrl)
      .client(client)
      .addConverterFactory(MoshiConverterFactory.create(moshi))
      .build()
      .create(PaymentProviderApi::class.java)
  }

  fun noticeForMethod(method: PaymentMethod): PaymentMethodNotice {
    return when (method) {
      PaymentMethod.DINHEIRO ->
        PaymentMethodNotice(
          method = PaymentMethod.DINHEIRO,
          isOnlineProviderConfigured = true,
          badgeLabelPtBr = "Pronto para uso",
          explanationPtBr =
            "Pagamento em espécie diretamente ao motorista ao finalizar a corrida ou entrega.",
        )

      PaymentMethod.PIX ->
        if (isProviderKeyConfigured) {
          PaymentMethodNotice(
            method = PaymentMethod.PIX,
            isOnlineProviderConfigured = true,
            badgeLabelPtBr = "Chave pública detectada",
            explanationPtBr =
              "Chave PAYMENT_PROVIDER_PUBLIC_KEY configurada. Conecte o endpoint do seu backend em PaymentGatewayService para emitir QR Code Pix dinâmico.",
          )
        } else {
          PaymentMethodNotice(
            method = PaymentMethod.PIX,
            isOnlineProviderConfigured = false,
            badgeLabelPtBr = "Integração Pix preparada",
            explanationPtBr =
              "Nenhuma cobrança Pix online é simulada. O pedido registra preferência por Pix para acerto presencial com o motorista até que um provedor (ex.: Mercado Pago / Asaas) seja configurado no painel Secrets.",
          )
        }

      PaymentMethod.CARTAO ->
        if (isProviderKeyConfigured) {
          PaymentMethodNotice(
            method = PaymentMethod.CARTAO,
            isOnlineProviderConfigured = true,
            badgeLabelPtBr = "Chave pública detectada",
            explanationPtBr =
              "Chave PAYMENT_PROVIDER_PUBLIC_KEY configurada. Conecte o SDK/tokenizador do seu provedor ao PaymentProviderApi para captura online.",
          )
        } else {
          PaymentMethodNotice(
            method = PaymentMethod.CARTAO,
            isOnlineProviderConfigured = false,
            badgeLabelPtBr = "Integração Cartão preparada",
            explanationPtBr =
              "Nenhum dado sensível de cartão é coletado nem simulado no app. O pedido registra preferência por cartão na maquininha até a configuração do provedor de pagamentos.",
          )
        }
    }
  }
}
