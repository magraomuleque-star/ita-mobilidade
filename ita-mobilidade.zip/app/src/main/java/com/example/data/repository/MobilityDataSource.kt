package com.example.data.repository

import com.example.data.model.DriverProfile
import com.example.data.model.OrderStatus
import com.example.data.model.PassengerProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.ServiceOrder
import com.example.data.model.ServiceType
import com.example.data.model.UserProfiles
import com.google.firebase.Timestamp
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

interface MobilityDataSource {
  val isCloudBacked: Boolean

  fun observeUserProfiles(userId: String): Flow<UserProfiles>

  fun observePassengerOrders(passengerId: String): Flow<List<ServiceOrder>>

  fun observeOpenOrdersForDriver(): Flow<List<ServiceOrder>>

  fun observeDriverOrders(driverId: String): Flow<List<ServiceOrder>>

  fun observeDeclinedOrderIds(driverId: String): Flow<Set<String>>

  suspend fun registerPassenger(fullName: String, phone: String): Result<Unit>

  suspend fun registerDriver(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ): Result<Unit>

  suspend fun updatePassengerProfile(fullName: String, phone: String): Result<Unit>

  suspend fun updateDriverProfile(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ): Result<Unit>

  suspend fun setDriverOnlineStatus(online: Boolean): Result<Unit>

  suspend fun createOrder(
    passengerName: String,
    serviceType: ServiceType,
    originAddress: String,
    destinationAddress: String,
    originLat: Double,
    originLng: Double,
    destLat: Double,
    destLng: Double,
    packageDescription: String,
    recipientName: String,
    paymentMethod: PaymentMethod,
    estimatedDistanceKm: Double,
    priceCents: Long,
  ): Result<String>

  suspend fun acceptOrder(orderId: String, driverProfile: DriverProfile): Result<Unit>

  suspend fun declineOrder(orderId: String): Result<Unit>

  suspend fun advanceOrderStatus(orderId: String, nextStatus: OrderStatus): Result<Unit>

  suspend fun cancelOrderByPassenger(orderId: String): Result<Unit>
}

/**
 * In-memory interactive session store used strictly when the user navigates directly to Passageiro
 * or Motorista in the preview before signing into a Google account.
 *
 * - Never performs unauthenticated Firestore queries or calls prohibited auth fallbacks.
 * - Starts with an empty orders list (no pre-populated fake orders); every order displayed is
 *   created interactively by the user during the session and shared live between Passageiro and
 *   Motorista screens so the full request -> accept -> status update flow can be tested in preview.
 */
class LocalInteractiveSessionDataSource : MobilityDataSource {
  override val isCloudBacked: Boolean = false

  private val _passengerProfile =
    MutableStateFlow(
      PassengerProfile(
        id = LOCAL_PASSENGER_ID,
        userId = LOCAL_PASSENGER_ID,
        fullName = "Passageiro ITA",
        email = "",
        phone = "(12) 99100-0000",
        createdAt = Timestamp.now(),
        updatedAt = Timestamp.now(),
      )
    )

  private val _driverProfile =
    MutableStateFlow(
      DriverProfile(
        id = LOCAL_DRIVER_ID,
        driverId = LOCAL_DRIVER_ID,
        fullName = "Motorista Parceiro ITA",
        email = "",
        phone = "(12) 99200-0000",
        vehicleModel = "Honda CG 160 Start",
        vehiclePlate = "ITA2E26",
        online = false,
        createdAt = Timestamp.now(),
        updatedAt = Timestamp.now(),
      )
    )

  private val _orders = MutableStateFlow<List<ServiceOrder>>(emptyList())
  private val _declinedIds = MutableStateFlow<Set<String>>(emptySet())

  fun resetForTesting() {
    _orders.value = emptyList()
    _declinedIds.value = emptySet()
    _driverProfile.update { it.copy(online = false) }
  }

  override fun observeUserProfiles(userId: String): Flow<UserProfiles> {
    return combine(_passengerProfile, _driverProfile) { passenger, driver ->
      UserProfiles(passenger = passenger, driver = driver)
    }
  }

  override fun observePassengerOrders(passengerId: String): Flow<List<ServiceOrder>> {
    return _orders.map { list ->
      list
        .filter { it.passengerId == LOCAL_PASSENGER_ID }
        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
    }
  }

  override fun observeOpenOrdersForDriver(): Flow<List<ServiceOrder>> {
    return _orders.map { list ->
      list
        .filter { it.status == OrderStatus.SOLICITADO.code }
        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
    }
  }

  override fun observeDriverOrders(driverId: String): Flow<List<ServiceOrder>> {
    return _orders.map { list ->
      list
        .filter { it.driverId == LOCAL_DRIVER_ID }
        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
    }
  }

  override fun observeDeclinedOrderIds(driverId: String): Flow<Set<String>> = _declinedIds

  override suspend fun registerPassenger(fullName: String, phone: String): Result<Unit> {
    return updatePassengerProfile(fullName, phone)
  }

  override suspend fun registerDriver(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ): Result<Unit> {
    return updateDriverProfile(fullName, phone, vehicleModel, vehiclePlate)
  }

  override suspend fun updatePassengerProfile(fullName: String, phone: String): Result<Unit> {
    val cleanName = fullName.trim()
    val cleanPhone = phone.trim()
    if (cleanName.length !in 2..80) {
      return Result.failure(
        IllegalArgumentException("Informe seu nome completo (entre 2 e 80 caracteres).")
      )
    }
    if (cleanPhone.length !in 8..25) {
      return Result.failure(IllegalArgumentException("Informe um telefone válido com DDD."))
    }
    _passengerProfile.update {
      it.copy(fullName = cleanName, phone = cleanPhone, updatedAt = Timestamp.now())
    }
    return Result.success(Unit)
  }

  override suspend fun updateDriverProfile(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ): Result<Unit> {
    val cleanName = fullName.trim()
    val cleanPhone = phone.trim()
    val cleanModel = vehicleModel.trim()
    val cleanPlate = vehiclePlate.trim().uppercase()
    if (cleanName.length !in 2..80) {
      return Result.failure(
        IllegalArgumentException("Informe seu nome completo (entre 2 e 80 caracteres).")
      )
    }
    if (cleanPhone.length !in 8..25) {
      return Result.failure(IllegalArgumentException("Informe um telefone válido com DDD."))
    }
    if (cleanModel.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe o modelo e a cor da sua moto."))
    }
    if (cleanPlate.length !in 5..16) {
      return Result.failure(IllegalArgumentException("Informe uma placa válida (ex.: BRA2E19)."))
    }
    _driverProfile.update {
      it.copy(
        fullName = cleanName,
        phone = cleanPhone,
        vehicleModel = cleanModel,
        vehiclePlate = cleanPlate,
        updatedAt = Timestamp.now(),
      )
    }
    return Result.success(Unit)
  }

  override suspend fun setDriverOnlineStatus(online: Boolean): Result<Unit> {
    _driverProfile.update { it.copy(online = online, updatedAt = Timestamp.now()) }
    return Result.success(Unit)
  }

  override suspend fun createOrder(
    passengerName: String,
    serviceType: ServiceType,
    originAddress: String,
    destinationAddress: String,
    originLat: Double,
    originLng: Double,
    destLat: Double,
    destLng: Double,
    packageDescription: String,
    recipientName: String,
    paymentMethod: PaymentMethod,
    estimatedDistanceKm: Double,
    priceCents: Long,
  ): Result<String> {
    val cleanOrigin = originAddress.trim()
    val cleanDest = destinationAddress.trim()
    val cleanPkg =
      if (serviceType == ServiceType.ENTREGA_PACOTE) packageDescription.trim() else ""
    val cleanRecipient =
      if (serviceType == ServiceType.ENTREGA_PACOTE) recipientName.trim() else ""

    if (cleanOrigin.length !in 3..200) {
      return Result.failure(
        IllegalArgumentException("Informe o endereço de origem (mínimo 3 caracteres).")
      )
    }
    if (cleanDest.length !in 3..200) {
      return Result.failure(
        IllegalArgumentException("Informe o endereço de destino (mínimo 3 caracteres).")
      )
    }
    if (cleanOrigin.equals(cleanDest, ignoreCase = true)) {
      return Result.failure(
        IllegalArgumentException("A origem e o destino devem ser endereços diferentes.")
      )
    }
    if (serviceType == ServiceType.ENTREGA_PACOTE && cleanPkg.length !in 2..200) {
      return Result.failure(
        IllegalArgumentException("Descreva o pacote que será enviado (mínimo 2 caracteres).")
      )
    }

    val now = Timestamp.now()
    val newId = "local_${UUID.randomUUID().toString().take(8)}"
    val newOrder =
      ServiceOrder(
        id = newId,
        passengerId = LOCAL_PASSENGER_ID,
        passengerName = passengerName.trim().take(80).ifBlank { "Passageiro ITA" },
        serviceType = serviceType.code,
        originAddress = cleanOrigin,
        destinationAddress = cleanDest,
        originLat = originLat.coerceIn(-90.0, 90.0),
        originLng = originLng.coerceIn(-180.0, 180.0),
        destLat = destLat.coerceIn(-90.0, 90.0),
        destLng = destLng.coerceIn(-180.0, 180.0),
        packageDescription = cleanPkg.take(200),
        recipientName = cleanRecipient.take(80),
        paymentMethod = paymentMethod.code,
        paymentStatus = PaymentStatus.initialForMethod(paymentMethod).code,
        estimatedDistanceKm = estimatedDistanceKm.coerceIn(0.5, 500.0),
        priceCents = priceCents.coerceIn(500L, 500000L),
        status = OrderStatus.SOLICITADO.code,
        driverId = "",
        driverName = "",
        driverVehicleModel = "",
        driverVehiclePlate = "",
        createdAt = now,
        updatedAt = now,
      )
    _orders.update { listOf(newOrder) + it }
    return Result.success(newId)
  }

  override suspend fun acceptOrder(orderId: String, driverProfile: DriverProfile): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    val existing = _orders.value.firstOrNull { it.id == orderId }
      ?: return Result.failure(IllegalStateException("Este pedido não foi encontrado."))

    if (existing.status != OrderStatus.SOLICITADO.code || existing.driverId.isNotBlank()) {
      return Result.failure(
        IllegalStateException(
          "Este chamado já foi aceito por outro motorista ou cancelado pelo passageiro."
        )
      )
    }

    _orders.update { current ->
      current.map { order ->
        if (order.id == orderId) {
          order.copy(
            status = OrderStatus.ACEITO.code,
            driverId = LOCAL_DRIVER_ID,
            driverName = driverProfile.fullName,
            driverVehicleModel = driverProfile.vehicleModel,
            driverVehiclePlate = driverProfile.vehiclePlate,
            updatedAt = Timestamp.now(),
          )
        } else {
          order
        }
      }
    }
    return Result.success(Unit)
  }

  override suspend fun declineOrder(orderId: String): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    _declinedIds.update { it + orderId }
    return Result.success(Unit)
  }

  override suspend fun advanceOrderStatus(
    orderId: String,
    nextStatus: OrderStatus,
  ): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    val existing = _orders.value.firstOrNull { it.id == orderId }
      ?: return Result.failure(IllegalStateException("Pedido não encontrado."))

    _orders.update { current ->
      current.map { order ->
        if (order.id == existing.id) {
          order.copy(
            status = nextStatus.code,
            paymentStatus =
              if (nextStatus == OrderStatus.CONCLUIDO) PaymentStatus.CONCLUIDO_PRESENCIAL.code
              else order.paymentStatus,
            updatedAt = Timestamp.now(),
          )
        } else {
          order
        }
      }
    }
    return Result.success(Unit)
  }

  override suspend fun cancelOrderByPassenger(orderId: String): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    _orders.update { current ->
      current.map { order ->
        if (order.id == orderId) {
          order.copy(status = OrderStatus.CANCELADO.code, updatedAt = Timestamp.now())
        } else {
          order
        }
      }
    }
    return Result.success(Unit)
  }

  companion object {
    const val LOCAL_SESSION_KEY = "local_interactive_preview_session"
    const val LOCAL_PASSENGER_ID = "sessao_passageiro_local"
    const val LOCAL_DRIVER_ID = "sessao_motorista_local"

    val shared = LocalInteractiveSessionDataSource()
  }
}
