package com.example.data.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.util.Locale
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class ResolvedGpsOrigin(
  val latitude: Double,
  val longitude: Double,
  val formattedAddress: String,
)

object LocationAndMapsHelper {
  private const val PLACEHOLDER_MAPS_KEY = "YOUR_GOOGLE_MAPS_API_KEY"

  private fun readOptionalMapsKey(): String {
    return runCatching {
        BuildConfig::class.java.getDeclaredField("GOOGLE_MAPS_API_KEY").get(null) as? String ?: ""
      }
      .getOrDefault("")
      .trim()
  }

  val isGoogleMapsKeyConfigured: Boolean
    get() {
      val key = readOptionalMapsKey()
      return key.isNotEmpty() && key != PLACEHOLDER_MAPS_KEY
    }

  fun hasLocationPermission(context: Context): Boolean {
    val fine =
      ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    val coarse =
      ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    return fine || coarse
  }

  @SuppressLint("MissingPermission")
  suspend fun fetchCurrentGpsOrigin(context: Context): Result<ResolvedGpsOrigin> {
    if (!hasLocationPermission(context)) {
      return Result.failure(
        IllegalStateException("Permissão de localização não concedida.")
      )
    }

    return try {
      val fusedClient = LocationServices.getFusedLocationProviderClient(context)
      val tokenSource = CancellationTokenSource()
      val location =
        fusedClient
          .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, tokenSource.token)
          .await()
          ?: fusedClient.lastLocation.await()
          ?: return Result.failure(
            IllegalStateException(
              "Sinal de GPS indisponível no momento. Digite o endereço de origem manualmente."
            )
          )

      val addressText = reverseGeocodePtBr(context, location.latitude, location.longitude)
      Result.success(
        ResolvedGpsOrigin(
          latitude = location.latitude,
          longitude = location.longitude,
          formattedAddress = addressText,
        )
      )
    } catch (e: Exception) {
      Result.failure(
        IllegalStateException(
          "Não foi possível obter a localização atual: ${e.localizedMessage ?: "verifique o GPS"}."
        )
      )
    }
  }

  private suspend fun reverseGeocodePtBr(
    context: Context,
    lat: Double,
    lng: Double,
  ): String =
    withContext(Dispatchers.IO) {
      val fallback =
        String.format(Locale.forLanguageTag("pt-BR"), "Localização GPS (%.5f, %.5f)", lat, lng)
      if (!Geocoder.isPresent()) return@withContext fallback

      val geocoder = Geocoder(context, Locale.forLanguageTag("pt-BR"))
      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          suspendCancellableCoroutine { cont ->
            geocoder.getFromLocation(lat, lng, 1) { addresses ->
              val line = addresses.firstOrNull()?.getAddressLine(0)
              if (cont.isActive) {
                cont.resume(line?.takeIf { it.isNotBlank() } ?: fallback)
              }
            }
          }
        } else {
          @Suppress("DEPRECATION")
          val addresses = geocoder.getFromLocation(lat, lng, 1)
          addresses?.firstOrNull()?.getAddressLine(0)?.takeIf { it.isNotBlank() } ?: fallback
        }
      } catch (_: Exception) {
        fallback
      }
    }

  fun openExternalGoogleMapsRoute(
    context: Context,
    originAddress: String,
    destinationAddress: String,
    onError: (String) -> Unit = {},
  ) {
    val encodedOrigin = Uri.encode(originAddress.trim())
    val encodedDest = Uri.encode(destinationAddress.trim())
    val uri =
      Uri.parse(
        "https://www.google.com/maps/dir/?api=1&origin=$encodedOrigin&destination=$encodedDest&travelmode=two-wheeler"
      )
    val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
      context.startActivity(intent)
    } catch (_: Exception) {
      onError("Não foi encontrado aplicativo de mapas ou navegador para abrir a rota.")
    }
  }
}
