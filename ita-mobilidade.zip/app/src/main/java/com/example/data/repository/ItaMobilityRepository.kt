package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.DeclinedOrder
import com.example.data.model.DriverProfile
import com.example.data.model.FareCalculator
import com.example.data.model.OrderStatus
import com.example.data.model.PassengerProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.RegisteredAccount
import com.example.data.model.ServiceOrder
import com.example.data.model.ServiceType
import com.example.data.model.UserProfiles
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ItaMobilityRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) : MobilityDataSource {
  override val isCloudBacked: Boolean = true
  constructor(context: Context) : this(
    db =
      FirebaseFirestore.getInstance(
        context.applicationContext.getString(R.string.firestore_database_id)
      ),
    auth = Firebase.auth,
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("Usuário precisa estar autenticado para realizar esta operação.")
  }

  private fun requireUserEmail(): String {
    val raw = auth.currentUser?.email?.trim().orEmpty()
    return if (raw.length >= 3) raw else "${requireUserId()}@itamobilidade.app"
  }

  // --- PERFIS (PASSAGEIRO E MOTORISTA SEPARADOS) ---

  fun observePassengerProfile(userId: String): Flow<PassengerProfile?> {
    val docRef = db.collection(COLLECTION_PASSENGERS).document(userId)
    return docRef
      .snapshots()
      .map { snapshot ->
        if (snapshot.exists()) {
          snapshot.toObject(
            PassengerProfile::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
        } else {
          null
        }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
        throw error
      }
  }

  fun observeDriverProfile(driverId: String): Flow<DriverProfile?> {
    val docRef = db.collection(COLLECTION_DRIVERS).document(driverId)
    return docRef
      .snapshots()
      .map { snapshot ->
        if (snapshot.exists()) {
          snapshot.toObject(
            DriverProfile::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
        } else {
          null
        }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
        throw error
      }
  }

  override fun observeUserProfiles(userId: String): Flow<UserProfiles> {
    return combine(
      observePassengerProfile(userId),
      observeDriverProfile(userId),
    ) { passenger, driver ->
      UserProfiles(passenger = passenger, driver = driver)
    }
  }

  fun observeRegisteredAccount(userId: String): Flow<RegisteredAccount?> {
    return observeUserProfiles(userId).map { profiles ->
      when {
        profiles.passenger != null -> RegisteredAccount.Passenger(profiles.passenger)
        profiles.driver != null -> RegisteredAccount.Driver(profiles.driver)
        else -> null
      }
    }
  }

  suspend fun getPassengerById(passengerId: String): Result<PassengerProfile?> {
    val docRef = db.collection(COLLECTION_PASSENGERS).document(passengerId)
    return try {
      val snapshot = docRef.get().await()
      val profile =
        if (snapshot.exists()) {
          snapshot.toObject(
            PassengerProfile::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
        } else {
          null
        }
      Result.success(profile)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun registerPassenger(fullName: String, phone: String): Result<Unit> {
    val cleanName = fullName.trim()
    val cleanPhone = phone.trim()
    if (cleanName.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe seu nome completo (entre 2 e 80 caracteres)."))
    }
    if (cleanPhone.length !in 8..25) {
      return Result.failure(IllegalArgumentException("Informe um telefone válido com DDD."))
    }

    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_PASSENGERS).document(uid)
    val payload =
      mapOf(
        "userId" to uid,
        "fullName" to cleanName,
        "email" to requireUserEmail(),
        "phone" to cleanPhone,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun registerDriver(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ): Result<Unit> {
    val cleanName = fullName.trim()
    val cleanPhone = phone.trim()
    val cleanModel = vehicleModel.trim()
    val cleanPlate = vehiclePlate.trim().uppercase()

    if (cleanName.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe seu nome completo (entre 2 e 80 caracteres)."))
    }
    if (cleanPhone.length !in 8..25) {
      return Result.failure(IllegalArgumentException("Informe um telefone válido com DDD."))
    }
    if (cleanModel.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe o modelo e a cor da sua moto."))
    }
    if (cleanPlate.length !in 5..16) {
      return Result.failure(IllegalArgumentException("Informe uma placa válida (ex.: BRA2E19)."))
    }

    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_DRIVERS).document(uid)
    val payload =
      mapOf(
        "driverId" to uid,
        "fullName" to cleanName,
        "email" to requireUserEmail(),
        "phone" to cleanPhone,
        "vehicleModel" to cleanModel,
        "vehiclePlate" to cleanPlate,
        "online" to false,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun updatePassengerProfile(fullName: String, phone: String): Result<Unit> {
    val cleanName = fullName.trim()
    val cleanPhone = phone.trim()
    if (cleanName.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe seu nome completo (entre 2 e 80 caracteres)."))
    }
    if (cleanPhone.length !in 8..25) {
      return Result.failure(IllegalArgumentException("Informe um telefone válido com DDD."))
    }

    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_PASSENGERS).document(uid)
    val payload =
      mapOf(
        "fullName" to cleanName,
        "phone" to cleanPhone,
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.update(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun updateDriverProfile(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ): Result<Unit> {
    val cleanName = fullName.trim()
    val cleanPhone = phone.trim()
    val cleanModel = vehicleModel.trim()
    val cleanPlate = vehiclePlate.trim().uppercase()

    if (cleanName.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe seu nome completo (entre 2 e 80 caracteres)."))
    }
    if (cleanPhone.length !in 8..25) {
      return Result.failure(IllegalArgumentException("Informe um telefone válido com DDD."))
    }
    if (cleanModel.length !in 2..80) {
      return Result.failure(IllegalArgumentException("Informe o modelo e a cor da sua moto."))
    }
    if (cleanPlate.length !in 5..16) {
      return Result.failure(IllegalArgumentException("Informe uma placa válida (ex.: BRA2E19)."))
    }

    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_DRIVERS).document(uid)
    val payload =
      mapOf(
        "fullName" to cleanName,
        "phone" to cleanPhone,
        "vehicleModel" to cleanModel,
        "vehiclePlate" to cleanPlate,
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.update(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun setDriverOnlineStatus(online: Boolean): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_DRIVERS).document(uid)
    val payload =
      mapOf(
        "online" to online,
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.update(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- PEDIDOS DE CORRIDA E ENTREGA EM TEMPO REAL ---

  override suspend fun createOrder(
    passengerName: String,
    serviceType: ServiceType,
    originAddress: String,
    destinationAddress: String,
    originLat: Double,
    originLng: Double,
    destLat: Double,
    destLng: Double,
    packageDescription: String,
    recipientName: String,
    paymentMethod: PaymentMethod,
    estimatedDistanceKm: Double,
    priceCents: Long,
  ): Result<String> {
    val cleanOrigin = originAddress.trim()
    val cleanDest = destinationAddress.trim()
    val cleanPkg = if (serviceType == ServiceType.ENTREGA_PACOTE) packageDescription.trim() else ""
    val cleanRecipient = if (serviceType == ServiceType.ENTREGA_PACOTE) recipientName.trim() else ""

    if (cleanOrigin.length !in 3..200) {
      return Result.failure(IllegalArgumentException("Informe o endereço de origem (mínimo 3 caracteres)."))
    }
    if (cleanDest.length !in 3..200) {
      return Result.failure(IllegalArgumentException("Informe o endereço de destino (mínimo 3 caracteres)."))
    }
    if (cleanOrigin.equals(cleanDest, ignoreCase = true)) {
      return Result.failure(IllegalArgumentException("A origem e o destino devem ser endereços diferentes."))
    }
    if (serviceType == ServiceType.ENTREGA_PACOTE && cleanPkg.length !in 2..200) {
      return Result.failure(IllegalArgumentException("Descreva o pacote que será enviado (mínimo 2 caracteres)."))
    }

    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_ORDERS).document()
    val safeDist = estimatedDistanceKm.coerceIn(0.5, 500.0)
    val safePrice = priceCents.coerceIn(500L, 500000L)
    val payload =
      mapOf(
        "passengerId" to uid,
        "passengerName" to passengerName.trim().take(80).ifBlank { "Passageiro" },
        "serviceType" to serviceType.code,
        "originAddress" to cleanOrigin,
        "destinationAddress" to cleanDest,
        "originLat" to originLat.coerceIn(-90.0, 90.0),
        "originLng" to originLng.coerceIn(-180.0, 180.0),
        "destLat" to destLat.coerceIn(-90.0, 90.0),
        "destLng" to destLng.coerceIn(-180.0, 180.0),
        "packageDescription" to cleanPkg.take(200),
        "recipientName" to cleanRecipient.take(80),
        "paymentMethod" to paymentMethod.code,
        "paymentStatus" to PaymentStatus.initialForMethod(paymentMethod).code,
        "estimatedDistanceKm" to safeDist,
        "priceCents" to safePrice,
        "status" to OrderStatus.SOLICITADO.code,
        "driverId" to "",
        "driverName" to "",
        "driverVehicleModel" to "",
        "driverVehiclePlate" to "",
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )

    return try {
      docRef.set(payload).await()
      Result.success(docRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  override fun observePassengerOrders(passengerId: String): Flow<List<ServiceOrder>> {
    return db
      .collection(COLLECTION_ORDERS)
      .whereEqualTo("passengerId", passengerId)
      .snapshots()
      .map { querySnapshot ->
        querySnapshot
          .toObjects(ServiceOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, COLLECTION_ORDERS)
        throw error
      }
  }

  override fun observeOpenOrdersForDriver(): Flow<List<ServiceOrder>> {
    return db
      .collection(COLLECTION_ORDERS)
      .whereEqualTo("status", OrderStatus.SOLICITADO.code)
      .snapshots()
      .map { querySnapshot ->
        querySnapshot
          .toObjects(ServiceOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, COLLECTION_ORDERS)
        throw error
      }
  }

  override fun observeDriverOrders(driverId: String): Flow<List<ServiceOrder>> {
    return db
      .collection(COLLECTION_ORDERS)
      .whereEqualTo("driverId", driverId)
      .snapshots()
      .map { querySnapshot ->
        querySnapshot
          .toObjects(ServiceOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, COLLECTION_ORDERS)
        throw error
      }
  }

  override fun observeDeclinedOrderIds(driverId: String): Flow<Set<String>> {
    val path = "$COLLECTION_DRIVERS/$driverId/$SUBCOLLECTION_DECLINED"
    return db
      .collection(COLLECTION_DRIVERS)
      .document(driverId)
      .collection(SUBCOLLECTION_DECLINED)
      .snapshots()
      .map { querySnapshot ->
        querySnapshot
          .toObjects(DeclinedOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .map { it.orderId.ifBlank { it.id } }
          .toSet()
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        throw error
      }
  }

  override suspend fun acceptOrder(orderId: String, driverProfile: DriverProfile): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    val uid = requireUserId()
    val docRef = db.collection(COLLECTION_ORDERS).document(orderId)
    val payload =
      mapOf(
        "status" to OrderStatus.ACEITO.code,
        "driverId" to uid,
        "driverName" to driverProfile.fullName,
        "driverVehicleModel" to driverProfile.vehicleModel,
        "driverVehiclePlate" to driverProfile.vehiclePlate,
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      db.runTransaction { transaction ->
          val snap = transaction.get(docRef)
          if (!snap.exists()) {
            throw IllegalStateException("Este pedido não foi encontrado.")
          }
          val orderPassengerId = snap.getString("passengerId").orEmpty()
          if (orderPassengerId == uid) {
            throw IllegalArgumentException(
              "Você não pode aceitar um pedido solicitado pela sua própria conta. Utilize uma segunda conta Google para testar o aceite como motorista."
            )
          }
          val currentStatus = snap.getString("status").orEmpty()
          val currentDriverId = snap.getString("driverId").orEmpty()
          if (currentStatus != OrderStatus.SOLICITADO.code || currentDriverId.isNotBlank()) {
            throw IllegalStateException(
              "Este chamado já foi aceito por outro motorista ou cancelado pelo passageiro."
            )
          }
          transaction.update(docRef, payload)
        }
        .await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun declineOrder(orderId: String): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    val uid = requireUserId()
    val docRef =
      db
        .collection(COLLECTION_DRIVERS)
        .document(uid)
        .collection(SUBCOLLECTION_DECLINED)
        .document(orderId)
    val payload =
      mapOf(
        "driverId" to uid,
        "orderId" to orderId,
        "createdAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun advanceOrderStatus(orderId: String, nextStatus: OrderStatus): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    val docRef = db.collection(COLLECTION_ORDERS).document(orderId)
    val payload =
      buildMap<String, Any> {
        put("status", nextStatus.code)
        if (nextStatus == OrderStatus.CONCLUIDO) {
          put("paymentStatus", PaymentStatus.CONCLUIDO_PRESENCIAL.code)
        }
        put("updatedAt", FieldValue.serverTimestamp())
      }
    return try {
      docRef.update(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  override suspend fun cancelOrderByPassenger(orderId: String): Result<Unit> {
    if (orderId.isBlank()) {
      return Result.failure(IllegalArgumentException("ID do pedido inválido."))
    }
    val docRef = db.collection(COLLECTION_ORDERS).document(orderId)
    val payload =
      mapOf(
        "status" to OrderStatus.CANCELADO.code,
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    return try {
      docRef.update(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  companion object {
    const val COLLECTION_PASSENGERS = "passengers"
    const val COLLECTION_DRIVERS = "drivers"
    const val SUBCOLLECTION_DECLINED = "declined_orders"
    const val COLLECTION_ORDERS = "orders"
  }
}
