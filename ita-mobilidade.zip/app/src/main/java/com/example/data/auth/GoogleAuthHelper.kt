package com.example.data.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException
import androidx.credentials.exceptions.GetCredentialUnsupportedException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

private const val AUTH_TAG = "Auth"
private const val AUTO_SIGN_IN_TIMEOUT_MS = 2_500L
private const val SHEET_APPEARANCE_WATCHDOG_MS = 3_500L

fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
  val listener = FirebaseAuth.AuthStateListener { authInstance ->
    trySend(authInstance.currentUser)
  }
  addAuthStateListener(listener)
  awaitClose { removeAuthStateListener(listener) }
}

private fun Context.findActivity(): Activity? {
  var current: Context = this
  while (current is ContextWrapper) {
    if (current is Activity) return current
    current = current.baseContext
  }
  return this as? Activity
}

fun isGoogleWebClientConfigured(context: Context): Boolean {
  return runCatching { context.getString(R.string.default_web_client_id).isNotBlank() }
    .getOrDefault(false)
}

fun isGooglePlayServicesReady(context: Context): Boolean {
  return runCatching {
      GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) ==
        ConnectionResult.SUCCESS
    }
    .getOrDefault(false)
}

fun attemptAutoSignIn(
  context: Context,
  credentialManager: CredentialManager,
  onAuthSuccess: () -> Unit,
  onUnauthenticated: () -> Unit,
  scope: CoroutineScope,
) {
  if (Firebase.auth.currentUser != null) {
    onAuthSuccess()
    return
  }

  val activity = context.findActivity()
  if (activity == null || !isGooglePlayServicesReady(activity)) {
    onUnauthenticated()
    return
  }

  val clientId =
    try {
      context.getString(R.string.default_web_client_id).takeIf { it.isNotBlank() }
    } catch (e: Exception) {
      Log.w(AUTH_TAG, "default_web_client_id indisponível na inicialização", e)
      null
    }

  if (clientId == null) {
    onUnauthenticated()
    return
  }

  // Exclusively one option (GetGoogleIdOption) per request for silent auto-sign-in
  val googleIdOption =
    GetGoogleIdOption.Builder()
      .setFilterByAuthorizedAccounts(true)
      .setServerClientId(clientId)
      .setAutoSelectEnabled(true)
      .build()

  val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()

  scope.launch {
    try {
      val result =
        withTimeout(AUTO_SIGN_IN_TIMEOUT_MS) {
          credentialManager.getCredential(activity, request)
        }
      val credential = result.credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        Firebase.auth.signInWithCredential(authCredential).await()
        onAuthSuccess()
      } else {
        onUnauthenticated()
      }
    } catch (e: Exception) {
      onUnauthenticated()
    }
  }
}

fun signInWithGoogleInteractive(
  context: Context,
  credentialManager: CredentialManager,
  scope: CoroutineScope,
  onAuthSuccess: () -> Unit,
  onAuthError: (String) -> Unit,
  onAuthCancelled: () -> Unit,
): Job? {
  val activity = context.findActivity()
  if (activity == null) {
    onAuthError(
      "Não foi possível abrir o seletor de contas Google neste contexto de tela. Você pode acessar diretamente pelos botões Passageiro ou Motorista."
    )
    return null
  }

  val clientId =
    try {
      context.getString(R.string.default_web_client_id).trim()
    } catch (e: Exception) {
      ""
    }

  if (clientId.isBlank()) {
    onAuthError(
      "O login com Google ainda não possui default_web_client_id configurado neste build. Utilize os botões Passageiro ou Motorista para testar o aplicativo."
    )
    return null
  }

  // Fast pre-flight check: if Google Play Services is missing or inactive in the preview/emulator,
  // report a clear message immediately instead of hanging on the system CredentialManager binder.
  val gmsStatus =
    runCatching { GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(activity) }
      .getOrDefault(ConnectionResult.SERVICE_MISSING)
  if (gmsStatus != ConnectionResult.SUCCESS) {
    Log.w(AUTH_TAG, "Google Play Services indisponível (status=$gmsStatus)")
    onAuthError(
      "O Google Play Services / Login com Google não está ativo neste ambiente de pré-visualização (código $gmsStatus). Para testar em nuvem, utilize um aparelho/emulador com conta Google conectada, ou toque agora nos botões Passageiro ou Motorista para usar todas as funcionalidades."
    )
    return null
  }

  // Exclusively one option (GetSignInWithGoogleOption) per interactive request
  val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
  val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

  var stalledWithoutPicker = false
  val authJob =
    scope.launch outerAuth@{
      val watchdog = launch {
        delay(SHEET_APPEARANCE_WATCHDOG_MS)
        // If MainActivity still holds window focus after 3.5s, the system account picker sheet
        // never appeared (common on cloud emulators with zero Google accounts configured).
        if (activity.hasWindowFocus()) {
          stalledWithoutPicker = true
          this@outerAuth.cancel(
            CancellationException("Seletor de contas Google não abriu na pré-visualização")
          )
        }
      }
      try {
        val result = credentialManager.getCredential(activity, request)
        watchdog.cancel()
        val credential = result.credential
        if (
          credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          Firebase.auth.signInWithCredential(authCredential).await()
          onAuthSuccess()
        } else {
          onAuthError(
            "Tipo de credencial inesperado retornado pelo provedor Google. Use os botões Passageiro ou Motorista para continuar."
          )
        }
      } catch (e: GetCredentialCancellationException) {
        watchdog.cancel()
        Log.w(AUTH_TAG, "Google Sign-In cancelled or dismissed: ${e.message}", e)
        onAuthCancelled()
      } catch (e: NoCredentialException) {
        watchdog.cancel()
        Log.w(AUTH_TAG, "Nenhuma conta Google configurada no dispositivo/emulador", e)
        onAuthError(
          "Nenhuma conta Google está conectada neste emulador/aparelho Android. Adicione uma conta Google nas Configurações do sistema para sincronizar com o Firebase ou toque em Passageiro / Motorista para usar o app agora."
        )
      } catch (e: GetCredentialProviderConfigurationException) {
        watchdog.cancel()
        Log.w(AUTH_TAG, "Provedor Google Play Services indisponível no ambiente", e)
        onAuthError(
          "O Google Play Services / Credential Manager não está configurado neste ambiente de pré-visualização. Toque nos botões Passageiro ou Motorista para testar todas as telas e pedidos."
        )
      } catch (e: GetCredentialUnsupportedException) {
        watchdog.cancel()
        Log.w(AUTH_TAG, "Credential Manager não suportado neste dispositivo", e)
        onAuthError(
          "Este dispositivo/emulador não suporta o seletor de contas Google. Acesse diretamente pelos botões Passageiro ou Motorista."
        )
      } catch (e: TimeoutCancellationException) {
        watchdog.cancel()
        Log.w(AUTH_TAG, "Tempo esgotado aguardando seletor de contas Google", e)
        onAuthError(
          "O seletor de contas do Google não respondeu na pré-visualização (emulador sem conta Google conectada). Adicione uma conta Google no Android ou toque em Passageiro / Motorista para acessar imediatamente."
        )
      } catch (e: GetCredentialException) {
        watchdog.cancel()
        Log.w(AUTH_TAG, "Exceção do CredentialManager no login com Google: ${e.type}", e)
        onAuthError(
          "Não foi possível abrir o login com Google neste emulador (${e.localizedMessage ?: "sem conta Google ativa"}). Você pode tocar em Passageiro ou Motorista para testar os recursos agora."
        )
      } catch (e: CancellationException) {
        watchdog.cancel()
        if (stalledWithoutPicker) {
          onAuthError(
            "O seletor de contas do Google não abriu neste emulador (nenhuma conta Google configurada no Android). Adicione uma conta Google nas Configurações do aparelho para usar o Firebase na nuvem, ou toque nos botões Passageiro e Motorista para usar o aplicativo agora."
          )
        } else {
          throw e
        }
      } catch (e: Exception) {
        watchdog.cancel()
        Log.e(AUTH_TAG, "Falha ao entrar com Google", e)
        onAuthError(
          "Não foi possível concluir o login com Google neste momento (${e.localizedMessage ?: "verifique a conta Google do aparelho"}). Use os botões Passageiro ou Motorista para continuar."
        )
      }
    }
  return authJob
}

fun signOutFromApp(
  credentialManager: CredentialManager,
  scope: CoroutineScope,
  onSignOutComplete: () -> Unit = {},
) {
  Firebase.auth.signOut()
  scope.launch {
    try {
      credentialManager.clearCredentialState(ClearCredentialStateRequest())
    } catch (e: Exception) {
      Log.w(AUTH_TAG, "Falha ao limpar estado do CredentialManager", e)
    } finally {
      onSignOutComplete()
    }
  }
}
