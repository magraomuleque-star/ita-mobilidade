package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt

enum class AccountMode(val labelPtBr: String) {
  PASSAGEIRO("Passageiro"),
  MOTORISTA("Motorista"),
}

enum class ServiceType(val code: String, val labelPtBr: String, val descriptionPtBr: String) {
  CORRIDA_MOTO(
    code = "CORRIDA_MOTO",
    labelPtBr = "Corrida de Moto",
    descriptionPtBr = "Viagem individual rápida de moto",
  ),
  ENTREGA_PACOTE(
    code = "ENTREGA_PACOTE",
    labelPtBr = "Entrega de Pacote",
    descriptionPtBr = "Envio ágil de documentos e pequenos volumes",
  );

  companion object {
    fun fromCode(code: String): ServiceType =
      entries.firstOrNull { it.code == code } ?: CORRIDA_MOTO
  }
}

enum class PaymentMethod(val code: String, val labelPtBr: String) {
  PIX("PIX", "Pix"),
  DINHEIRO("DINHEIRO", "Dinheiro"),
  CARTAO("CARTAO", "Cartão");

  companion object {
    fun fromCode(code: String): PaymentMethod =
      entries.firstOrNull { it.code == code } ?: DINHEIRO
  }
}

enum class PaymentStatus(val code: String, val labelPtBr: String) {
  PAGAMENTO_NA_ENTREGA("PAGAMENTO_NA_ENTREGA", "Acerto em dinheiro na conclusão"),
  AGUARDANDO_PROVEDOR_PIX(
    "AGUARDANDO_PROVEDOR_PIX",
    "Preferência Pix (provedor online pendente — acerto presencial)",
  ),
  AGUARDANDO_PROVEDOR_CARTAO(
    "AGUARDANDO_PROVEDOR_CARTAO",
    "Preferência Cartão (provedor online pendente — maquininha presencial)",
  ),
  CONCLUIDO_PRESENCIAL("CONCLUIDO_PRESENCIAL", "Serviço encerrado (acerto presencial)");

  companion object {
    fun fromCode(code: String): PaymentStatus =
      entries.firstOrNull { it.code == code } ?: PAGAMENTO_NA_ENTREGA

    fun initialForMethod(method: PaymentMethod): PaymentStatus =
      when (method) {
        PaymentMethod.DINHEIRO -> PAGAMENTO_NA_ENTREGA
        PaymentMethod.PIX -> AGUARDANDO_PROVEDOR_PIX
        PaymentMethod.CARTAO -> AGUARDANDO_PROVEDOR_CARTAO
      }
  }
}

enum class OrderStatus(
  val code: String,
  val labelPtBr: String,
  val stepIndex: Int,
) {
  SOLICITADO("SOLICITADO", "Aguardando motorista", 0),
  ACEITO("ACEITO", "Motorista aceitou o pedido", 1),
  A_CAMINHO("A_CAMINHO", "Motorista a caminho da origem", 2),
  EM_ANDAMENTO("EM_ANDAMENTO", "Em andamento rumo ao destino", 3),
  CONCLUIDO("CONCLUIDO", "Concluído", 4),
  CANCELADO("CANCELADO", "Cancelado", -1);

  val isActive: Boolean
    get() = this in listOf(SOLICITADO, ACEITO, A_CAMINHO, EM_ANDAMENTO)

  companion object {
    fun fromCode(code: String): OrderStatus =
      entries.firstOrNull { it.code == code } ?: SOLICITADO
  }
}

@IgnoreExtraProperties
data class PassengerProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class DriverProfile(
  @DocumentId val id: String = "",
  val driverId: String = "",
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val vehicleModel: String = "",
  val vehiclePlate: String = "",
  val online: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class DeclinedOrder(
  @DocumentId val id: String = "",
  val driverId: String = "",
  val orderId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ServiceOrder(
  @DocumentId val id: String = "",
  val passengerId: String = "",
  val passengerName: String = "",
  val serviceType: String = ServiceType.CORRIDA_MOTO.code,
  val originAddress: String = "",
  val destinationAddress: String = "",
  val originLat: Double = -23.2015,
  val originLng: Double = -45.8895,
  val destLat: Double = -23.1862,
  val destLng: Double = -45.8741,
  val packageDescription: String = "",
  val recipientName: String = "",
  val paymentMethod: String = PaymentMethod.DINHEIRO.code,
  val paymentStatus: String = PaymentStatus.PAGAMENTO_NA_ENTREGA.code,
  val estimatedDistanceKm: Double = 2.5,
  val priceCents: Long = 1125L,
  val status: String = OrderStatus.SOLICITADO.code,
  val driverId: String = "",
  val driverName: String = "",
  val driverVehicleModel: String = "",
  val driverVehiclePlate: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  val typedService: ServiceType
    get() = ServiceType.fromCode(serviceType)

  val typedPaymentMethod: PaymentMethod
    get() = PaymentMethod.fromCode(paymentMethod)

  val typedPaymentStatus: PaymentStatus
    get() = PaymentStatus.fromCode(paymentStatus)

  val typedStatus: OrderStatus
    get() = OrderStatus.fromCode(status)
}

sealed interface RegisteredAccount {
  data class Passenger(val profile: PassengerProfile) : RegisteredAccount
  data class Driver(val profile: DriverProfile) : RegisteredAccount
}

data class UserProfiles(
  val passenger: PassengerProfile? = null,
  val driver: DriverProfile? = null,
)

data class GeoPointEstimate(
  val originLat: Double,
  val originLng: Double,
  val destLat: Double,
  val destLng: Double,
  val distanceKm: Double,
  val hasRealGpsOrigin: Boolean,
)

object FareCalculator {
  private val ptBrLocale = Locale.forLanguageTag("pt-BR")

  fun calculateDistanceKm(
    originLat: Double,
    originLng: Double,
    destLat: Double,
    destLng: Double,
  ): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(destLat - originLat)
    val dLng = Math.toRadians(destLng - originLng)
    val a =
      sin(dLat / 2) * sin(dLat / 2) +
        cos(Math.toRadians(originLat)) *
          cos(Math.toRadians(destLat)) *
          sin(dLng / 2) *
          sin(dLng / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    val straightLineKm = earthRadiusKm * c
    // Urban road factor (~1.28x straight line), clamped to safe bounds [1.2 km, 120.0 km]
    val urbanKm = (straightLineKm * 1.28).coerceIn(1.2, 120.0)
    return (urbanKm * 10.0).roundToLong() / 10.0
  }

  fun estimateCoordinatesFromAddresses(
    originAddress: String,
    destinationAddress: String,
    gpsLat: Double? = null,
    gpsLng: Double? = null,
  ): GeoPointEstimate {
    // Base urban center (São José dos Campos / ITA region reference)
    val baseLat = gpsLat ?: -23.2087
    val baseLng = gpsLng ?: -45.8769
    val originHash = originAddress.trim().lowercase(ptBrLocale).hashCode()
    val destHash = destinationAddress.trim().lowercase(ptBrLocale).hashCode()

    val oLat =
      gpsLat ?: (baseLat + ((originHash and 0xFF) - 128) * 0.00018)
    val oLng =
      gpsLng ?: (baseLng + (((originHash shr 8) and 0xFF) - 128) * 0.00018)

    val deltaLatOffset = max(0.012, (((destHash and 0xFF) % 60) + 14) * 0.00045)
    val deltaLngOffset = max(0.010, ((((destHash shr 8) and 0xFF) % 60) + 12) * 0.00042)
    val signLat = if ((destHash and 1) == 0) 1.0 else -1.0
    val signLng = if ((destHash and 2) == 0) 1.0 else -1.0

    val dLat = (oLat + signLat * deltaLatOffset).coerceIn(-89.0, 89.0)
    val dLng = (oLng + signLng * deltaLngOffset).coerceIn(-179.0, 179.0)
    val distKm = calculateDistanceKm(oLat, oLng, dLat, dLng)

    return GeoPointEstimate(
      originLat = oLat,
      originLng = oLng,
      destLat = dLat,
      destLng = dLng,
      distanceKm = distKm,
      hasRealGpsOrigin = gpsLat != null && gpsLng != null,
    )
  }

  fun calculatePriceCents(serviceType: ServiceType, distanceKm: Double): Long {
    val safeKm = distanceKm.coerceAtLeast(1.0)
    val rawCents =
      when (serviceType) {
        ServiceType.CORRIDA_MOTO -> 650.0 + (safeKm * 195.0)
        ServiceType.ENTREGA_PACOTE -> 800.0 + (safeKm * 225.0)
      }
    // Round to nearest 10 cents and enforce [500, 500000]
    val rounded = ((rawCents / 10.0).roundToLong() * 10L)
    return rounded.coerceIn(650L, 500000L)
  }

  fun formatCurrencyBrl(cents: Long): String {
    val formatter = NumberFormat.getCurrencyInstance(ptBrLocale)
    return formatter.format(cents / 100.0)
  }

  fun formatTimestampPtBr(timestamp: Timestamp?): String {
    val date = (timestamp ?: Timestamp.now()).toDate()
    val sdf = SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", ptBrLocale)
    return sdf.format(date)
  }
}
