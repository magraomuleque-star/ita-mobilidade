package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.auth.authStateFlow
import com.example.data.auth.signOutFromApp
import com.example.data.model.AccountMode
import com.example.data.repository.ItaMobilityRepository
import com.example.data.repository.LocalInteractiveSessionDataSource
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DriverHomeScreen
import com.example.ui.screens.PassengerHomeScreen
import com.example.ui.screens.RegistrationScreen
import com.example.ui.theme.ItaMobilidadeTheme
import com.example.ui.viewmodel.AccountUiState
import com.example.ui.viewmodel.MobilityViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

enum class AppScreenDestination {
  HOME,
  PASSENGER,
  DRIVER,
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      ItaMobilidadeTheme {
        Surface(
          color = MaterialTheme.colorScheme.background,
          modifier = Modifier.fillMaxSize(),
        ) {
          ItaMobilidadeApp()
        }
      }
    }
  }
}

@Composable
fun ItaMobilidadeApp(auth: FirebaseAuth? = runCatching { Firebase.auth }.getOrNull()) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  val currentUser: FirebaseUser? =
    if (auth != null) {
      val state by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
      state
    } else {
      null
    }

  var destination by rememberSaveable { mutableStateOf(AppScreenDestination.HOME) }

  val handleSignOut: () -> Unit = {
    signOutFromApp(
      credentialManager = credentialManager,
      scope = scope,
      onSignOutComplete = { destination = AppScreenDestination.HOME },
    )
  }

  when (destination) {
    AppScreenDestination.HOME -> {
      AuthScreen(
        onAuthSuccess = { destination = AppScreenDestination.PASSENGER },
        onOpenPassenger = { destination = AppScreenDestination.PASSENGER },
        onOpenDriver = { destination = AppScreenDestination.DRIVER },
        signedInEmail = currentUser?.email,
        onSignOut = if (currentUser != null) handleSignOut else null,
      )
    }

    AppScreenDestination.PASSENGER,
    AppScreenDestination.DRIVER -> {
      val targetMode =
        if (destination == AppScreenDestination.DRIVER) AccountMode.MOTORISTA
        else AccountMode.PASSAGEIRO

      ActiveModeShell(
        authenticatedUser = currentUser,
        targetMode = targetMode,
        onNavigateBackToHome = { destination = AppScreenDestination.HOME },
        onChangeDestination = { nextMode ->
          destination =
            if (nextMode == AccountMode.MOTORISTA) AppScreenDestination.DRIVER
            else AppScreenDestination.PASSENGER
        },
        onSignOut = handleSignOut,
      )
    }
  }
}

@Composable
private fun ActiveModeShell(
  authenticatedUser: FirebaseUser?,
  targetMode: AccountMode,
  onNavigateBackToHome: () -> Unit,
  onChangeDestination: (AccountMode) -> Unit,
  onSignOut: () -> Unit,
) {
  val sessionKey =
    if (authenticatedUser != null) {
      "cloud_${authenticatedUser.uid}"
    } else {
      LocalInteractiveSessionDataSource.LOCAL_SESSION_KEY
    }

  val viewModel: MobilityViewModel =
    viewModel(
      key = sessionKey,
      factory =
        viewModelFactory {
          initializer {
            if (authenticatedUser != null) {
              val app =
                checkNotNull(this[APPLICATION_KEY]) {
                  "APPLICATION_KEY ausente em CreationExtras"
                }
              val databaseId = app.getString(R.string.firestore_database_id)
              val db = FirebaseFirestore.getInstance(databaseId)
              MobilityViewModel(
                repository = ItaMobilityRepository(db),
                currentUserId = authenticatedUser.uid,
                initialDisplayName = authenticatedUser.displayName.orEmpty(),
                initialMode = targetMode,
              )
            } else {
              MobilityViewModel(
                repository = LocalInteractiveSessionDataSource.shared,
                currentUserId = LocalInteractiveSessionDataSource.LOCAL_SESSION_KEY,
                initialDisplayName = "Usuário ITA",
                initialMode = targetMode,
              )
            }
          }
        },
    )

  LaunchedEffect(sessionKey, targetMode) {
    viewModel.selectModeFromHome(targetMode)
  }

  val accountState by viewModel.accountState.collectAsStateWithLifecycle()
  val passengerOrders by viewModel.passengerOrdersState.collectAsStateWithLifecycle()
  val driverIncoming by viewModel.driverIncomingOrdersState.collectAsStateWithLifecycle()
  val driverAssigned by viewModel.driverAssignedOrdersState.collectAsStateWithLifecycle()
  val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
  val feedback by viewModel.feedback.collectAsStateWithLifecycle()

  when (val state = accountState) {
    is AccountUiState.Loading -> {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize(),
      ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Carregando seu perfil no ITA Mobilidade…",
          style = MaterialTheme.typography.bodyMedium,
        )
      }
    }

    is AccountUiState.NeedsRegistration -> {
      RegistrationScreen(
        suggestedName = state.suggestedName,
        userEmail = authenticatedUser?.email.orEmpty(),
        isBusy = isBusy,
        feedback = feedback,
        onDismissFeedback = viewModel::clearFeedback,
        onRegisterPassenger = { name, phone ->
          onChangeDestination(AccountMode.PASSAGEIRO)
          viewModel.registerPassenger(name, phone)
        },
        onRegisterDriver = { name, phone, model, plate ->
          onChangeDestination(AccountMode.MOTORISTA)
          viewModel.registerDriver(name, phone, model, plate)
        },
        onSignOut = onSignOut,
        onNavigateBack = onNavigateBackToHome,
        forcedMode = state.forcedMode,
        onCancelSecondaryRegistration =
          if (state.canCancelBack) {
            {
              val fallbackMode =
                if (state.forcedMode == AccountMode.MOTORISTA) AccountMode.PASSAGEIRO
                else AccountMode.MOTORISTA
              onChangeDestination(fallbackMode)
              viewModel.cancelSecondaryRegistration()
            }
          } else {
            null
          },
      )
    }

    is AccountUiState.PassengerReady -> {
      PassengerHomeScreen(
        profile = state.profile,
        hasDriverProfile = state.hasDriverProfile,
        ordersState = passengerOrders,
        isBusy = isBusy,
        feedback = feedback,
        viewModel = viewModel,
        onNavigateBack = onNavigateBackToHome,
        onSwitchToDriverMode = { onChangeDestination(AccountMode.MOTORISTA) },
        onSignOut = onSignOut,
      )
    }

    is AccountUiState.DriverReady -> {
      DriverHomeScreen(
        profile = state.profile,
        hasPassengerProfile = state.hasPassengerProfile,
        incomingOrdersState = driverIncoming,
        assignedOrdersState = driverAssigned,
        isBusy = isBusy,
        feedback = feedback,
        viewModel = viewModel,
        onNavigateBack = onNavigateBackToHome,
        onSwitchToPassengerMode = { onChangeDestination(AccountMode.PASSAGEIRO) },
        onSignOut = onSignOut,
      )
    }

    is AccountUiState.Error -> {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize().padding(24.dp),
      ) {
        Text(
          text = state.message,
          style = MaterialTheme.typography.bodyLarge,
          color = MaterialTheme.colorScheme.error,
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedButton(
          onClick = onNavigateBackToHome,
          modifier = Modifier.testTag("error_back_home_button"),
        ) {
          Text("Voltar para a tela inicial")
        }
        if (authenticatedUser != null) {
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = onSignOut,
            modifier = Modifier.testTag("error_sign_out_button"),
          ) {
            Text("Trocar de conta / Tentar novamente")
          }
        }
      }
    }
  }
}
