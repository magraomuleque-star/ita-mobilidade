package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Palette — ITA Mobilidade (Urban Slate, Moto Emerald & Delivery Amber)
val EmeraldPrimaryLight = Color(0xFF059669)
val OnEmeraldPrimaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFD1FAE5)
val OnEmeraldContainerLight = Color(0xFF064E3B)

val SlateSecondaryLight = Color(0xFF1E293B)
val OnSlateSecondaryLight = Color(0xFFFFFFFF)
val SlateContainerLight = Color(0xFFE2E8F0)
val OnSlateContainerLight = Color(0xFF0F172A)

val AmberTertiaryLight = Color(0xFFD97706)
val OnAmberTertiaryLight = Color(0xFFFFFFFF)
val AmberContainerLight = Color(0xFFFEF3C7)
val OnAmberContainerLight = Color(0xFF78350F)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme
val EmeraldPrimaryDark = Color(0xFF34D399)
val OnEmeraldPrimaryDark = Color(0xFF022C22)
val EmeraldContainerDark = Color(0xFF065F46)
val OnEmeraldContainerDark = Color(0xFFD1FAE5)

val SlateSecondaryDark = Color(0xFF94A3B8)
val OnSlateSecondaryDark = Color(0xFF0F172A)
val SlateContainerDark = Color(0xFF1E293B)
val OnSlateContainerDark = Color(0xFFE2E8F0)

val AmberTertiaryDark = Color(0xFFFBBF24)
val OnAmberTertiaryDark = Color(0xFF451A03)
val AmberContainerDark = Color(0xFF78350F)
val OnAmberContainerDark = Color(0xFFFEF3C7)

val BackgroundDark = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF111827)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)
