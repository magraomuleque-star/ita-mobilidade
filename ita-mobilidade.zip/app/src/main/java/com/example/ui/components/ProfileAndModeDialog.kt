package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AccountMode
import com.example.data.model.DriverProfile
import com.example.data.model.PassengerProfile
import com.google.firebase.FirebaseApp

@Composable
fun ProfileAndModeDialog(
  currentMode: AccountMode,
  passengerProfile: PassengerProfile?,
  driverProfile: DriverProfile?,
  hasOtherProfile: Boolean,
  isBusy: Boolean,
  isCloudSynced: Boolean = true,
  onSavePassenger: (fullName: String, phone: String) -> Unit,
  onSaveDriver: (fullName: String, phone: String, model: String, plate: String) -> Unit,
  onSwitchOrActivateOtherMode: () -> Unit,
  onDismiss: () -> Unit,
) {
  BackHandler(onBack = onDismiss)

  val context = LocalContext.current
  val firebaseProjectId =
    remember {
      runCatching { FirebaseApp.getInstance().options.projectId.orEmpty() }.getOrDefault("")
    }
  val databaseId = remember(context) { context.getString(R.string.firestore_database_id) }

  var fullName by
    rememberSaveable(currentMode, passengerProfile?.fullName, driverProfile?.fullName) {
      mutableStateOf(
        if (currentMode == AccountMode.PASSAGEIRO) passengerProfile?.fullName.orEmpty()
        else driverProfile?.fullName.orEmpty()
      )
    }
  var phone by
    rememberSaveable(currentMode, passengerProfile?.phone, driverProfile?.phone) {
      mutableStateOf(
        if (currentMode == AccountMode.PASSAGEIRO) passengerProfile?.phone.orEmpty()
        else driverProfile?.phone.orEmpty()
      )
    }
  var vehicleModel by
    rememberSaveable(driverProfile?.vehicleModel) {
      mutableStateOf(driverProfile?.vehicleModel.orEmpty())
    }
  var vehiclePlate by
    rememberSaveable(driverProfile?.vehiclePlate) {
      mutableStateOf(driverProfile?.vehiclePlate.orEmpty())
    }

  val emailDisplay =
    if (currentMode == AccountMode.PASSAGEIRO) passengerProfile?.email.orEmpty()
    else driverProfile?.email.orEmpty()

  val otherModeLabel =
    when {
      currentMode == AccountMode.PASSAGEIRO && hasOtherProfile ->
        stringResource(R.string.switch_to_driver_mode)
      currentMode == AccountMode.PASSAGEIRO ->
        stringResource(R.string.activate_driver_profile)
      hasOtherProfile -> stringResource(R.string.switch_to_passenger_mode)
      else -> stringResource(R.string.activate_passenger_profile)
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector =
            if (currentMode == AccountMode.PASSAGEIRO) Icons.Filled.Person
            else Icons.Filled.TwoWheeler,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "Perfil de ${currentMode.labelPtBr}")
      }
    },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
      ) {
        Surface(
          color =
            if (isCloudSynced) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
            else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f),
          shape = MaterialTheme.shapes.medium,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.CloudDone,
              contentDescription = if (isCloudSynced) "Firebase conectado" else "Sessão local",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text =
                  if (isCloudSynced) "Firebase Auth & Firestore conectados"
                  else "Sessão interativa local (sem conta Google ativa)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color =
                  if (isCloudSynced) MaterialTheme.colorScheme.onPrimaryContainer
                  else MaterialTheme.colorScheme.onSecondaryContainer,
              )
              if (emailDisplay.isNotBlank()) {
                Text(
                  text = emailDisplay,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
              }
              Text(
                text =
                  "Projeto Firebase: ${firebaseProjectId.ifBlank { "Ativo" }} • DB: ${databaseId.take(24)}…",
                style = MaterialTheme.typography.labelSmall,
                color =
                  if (isCloudSynced) MaterialTheme.colorScheme.onPrimaryContainer
                  else MaterialTheme.colorScheme.onSecondaryContainer,
              )
            }
          }
        }

        OutlinedTextField(
          value = fullName,
          onValueChange = { fullName = it },
          label = { Text(stringResource(R.string.field_full_name)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
          modifier = Modifier.fillMaxWidth().testTag("edit_profile_name_input"),
        )

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text(stringResource(R.string.field_phone)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          modifier = Modifier.fillMaxWidth().testTag("edit_profile_phone_input"),
        )

        if (currentMode == AccountMode.MOTORISTA) {
          OutlinedTextField(
            value = vehicleModel,
            onValueChange = { vehicleModel = it },
            label = { Text(stringResource(R.string.field_vehicle_model)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            modifier = Modifier.fillMaxWidth().testTag("edit_profile_vehicle_model_input"),
          )
          OutlinedTextField(
            value = vehiclePlate,
            onValueChange = { vehiclePlate = it.uppercase().take(10) },
            label = { Text(stringResource(R.string.field_vehicle_plate)) },
            singleLine = true,
            keyboardOptions =
              KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth().testTag("edit_profile_vehicle_plate_input"),
          )
        }

        Button(
          onClick = {
            if (currentMode == AccountMode.PASSAGEIRO) {
              onSavePassenger(fullName, phone)
            } else {
              onSaveDriver(fullName, phone, vehicleModel, vehiclePlate)
            }
          },
          enabled = !isBusy,
          modifier = Modifier.fillMaxWidth().testTag("save_profile_changes_button"),
        ) {
          Text(stringResource(R.string.save_profile_changes))
        }

        HorizontalDivider()

        Text(
          text = "Alternância entre Passageiro e Motorista",
          style = MaterialTheme.typography.titleSmall,
        )
        Text(
          text =
            "Os dados de Passageiro (/passengers) e Motorista (/drivers) ficam salvos em coleções separadas no Cloud Firestore.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        OutlinedButton(
          onClick = {
            onDismiss()
            onSwitchOrActivateOtherMode()
          },
          enabled = !isBusy,
          modifier = Modifier.fillMaxWidth().testTag("switch_account_mode_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.SwapHoriz,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(otherModeLabel)
        }
      }
    },
    confirmButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("close_profile_dialog_button"),
      ) {
        Text("Fechar")
      }
    },
  )
}
