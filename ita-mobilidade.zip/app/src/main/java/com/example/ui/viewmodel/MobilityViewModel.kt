package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.toFriendlyPtBrErrorMessage
import com.example.data.model.AccountMode
import com.example.data.model.DriverProfile
import com.example.data.model.FareCalculator
import com.example.data.model.OrderStatus
import com.example.data.model.PassengerProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.ServiceOrder
import com.example.data.model.ServiceType
import com.example.data.model.UserProfiles
import com.example.data.repository.MobilityDataSource
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}

sealed interface AccountUiState {
  data object Loading : AccountUiState
  data class NeedsRegistration(
    val suggestedName: String,
    val forcedMode: AccountMode? = null,
    val canCancelBack: Boolean = false,
  ) : AccountUiState
  data class PassengerReady(
    val profile: PassengerProfile,
    val hasDriverProfile: Boolean = false,
  ) : AccountUiState
  data class DriverReady(
    val profile: DriverProfile,
    val hasPassengerProfile: Boolean = false,
  ) : AccountUiState
  data class Error(val message: String) : AccountUiState
}

data class FeedbackBanner(
  val message: String,
  val isError: Boolean = false,
)

@OptIn(ExperimentalCoroutinesApi::class)
class MobilityViewModel(
  private val repository: MobilityDataSource,
  val currentUserId: String,
  private val initialDisplayName: String,
  initialMode: AccountMode? = null,
) : ViewModel() {

  val isCloudSynced: Boolean = repository.isCloudBacked

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private val _feedback = MutableStateFlow<FeedbackBanner?>(null)
  val feedback: StateFlow<FeedbackBanner?> = _feedback.asStateFlow()

  private val _preferredMode = MutableStateFlow<AccountMode?>(initialMode)
  private val _secondaryRegistrationTarget = MutableStateFlow<AccountMode?>(null)

  val accountState: StateFlow<AccountUiState> =
    combine(
      repository.observeUserProfiles(currentUserId),
      _preferredMode,
      _secondaryRegistrationTarget,
    ) { profiles: UserProfiles, preferred: AccountMode?, secondaryReg: AccountMode? ->
      val pass = profiles.passenger
      val drv = profiles.driver

      when {
        pass == null && drv == null ->
          AccountUiState.NeedsRegistration(
            suggestedName = initialDisplayName,
            forcedMode = preferred,
            canCancelBack = false,
          )

        secondaryReg == AccountMode.MOTORISTA && drv == null ->
          AccountUiState.NeedsRegistration(
            suggestedName = pass?.fullName?.ifBlank { initialDisplayName } ?: initialDisplayName,
            forcedMode = AccountMode.MOTORISTA,
            canCancelBack = pass != null,
          )

        secondaryReg == AccountMode.PASSAGEIRO && pass == null ->
          AccountUiState.NeedsRegistration(
            suggestedName = drv?.fullName?.ifBlank { initialDisplayName } ?: initialDisplayName,
            forcedMode = AccountMode.PASSAGEIRO,
            canCancelBack = drv != null,
          )

        preferred == AccountMode.MOTORISTA && drv == null ->
          AccountUiState.NeedsRegistration(
            suggestedName = pass?.fullName?.ifBlank { initialDisplayName } ?: initialDisplayName,
            forcedMode = AccountMode.MOTORISTA,
            canCancelBack = pass != null,
          )

        preferred == AccountMode.PASSAGEIRO && pass == null ->
          AccountUiState.NeedsRegistration(
            suggestedName = drv?.fullName?.ifBlank { initialDisplayName } ?: initialDisplayName,
            forcedMode = AccountMode.PASSAGEIRO,
            canCancelBack = drv != null,
          )

        preferred == AccountMode.MOTORISTA && drv != null ->
          AccountUiState.DriverReady(profile = drv, hasPassengerProfile = pass != null)

        preferred == AccountMode.PASSAGEIRO && pass != null ->
          AccountUiState.PassengerReady(profile = pass, hasDriverProfile = drv != null)

        pass != null ->
          AccountUiState.PassengerReady(profile = pass, hasDriverProfile = drv != null)

        drv != null ->
          AccountUiState.DriverReady(profile = drv, hasPassengerProfile = false)

        else -> AccountUiState.NeedsRegistration(suggestedName = initialDisplayName)
      }
    }
      .catch { error ->
        Log.w(TAG, "Erro ao observar perfil do usuário", error)
        emit(AccountUiState.Error(toFriendlyPtBrErrorMessage(error)))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = AccountUiState.Loading,
      )

  val passengerOrdersState: StateFlow<UiState<List<ServiceOrder>>> =
    accountState
      .flatMapLatest { acc ->
        if (acc is AccountUiState.PassengerReady) {
          repository
            .observePassengerOrders(currentUserId)
            .map<List<ServiceOrder>, UiState<List<ServiceOrder>>> { UiState.Success(it) }
            .catch { error ->
              Log.w(TAG, "Erro ao observar pedidos do passageiro", error)
              emit(UiState.Error(toFriendlyPtBrErrorMessage(error)))
            }
        } else {
          flowOf(UiState.Success(emptyList()))
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Loading,
      )

  val driverIncomingOrdersState: StateFlow<UiState<List<ServiceOrder>>> =
    accountState
      .flatMapLatest { acc ->
        if (acc is AccountUiState.DriverReady && acc.profile.online) {
          combine(
            repository.observeOpenOrdersForDriver(),
            repository.observeDeclinedOrderIds(currentUserId),
          ) { openOrders, declinedIds ->
            openOrders.filterNot { order ->
              order.id in declinedIds || (isCloudSynced && order.passengerId == currentUserId)
            }
          }
            .map<List<ServiceOrder>, UiState<List<ServiceOrder>>> { UiState.Success(it) }
            .catch { error ->
              Log.w(TAG, "Erro ao observar fila de chamados do motorista", error)
              emit(UiState.Error(toFriendlyPtBrErrorMessage(error)))
            }
        } else {
          flowOf(UiState.Success(emptyList()))
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Success(emptyList()),
      )

  val driverAssignedOrdersState: StateFlow<UiState<List<ServiceOrder>>> =
    accountState
      .flatMapLatest { acc ->
        if (acc is AccountUiState.DriverReady) {
          repository
            .observeDriverOrders(currentUserId)
            .map<List<ServiceOrder>, UiState<List<ServiceOrder>>> { UiState.Success(it) }
            .catch { error ->
              Log.w(TAG, "Erro ao observar serviços do motorista", error)
              emit(UiState.Error(toFriendlyPtBrErrorMessage(error)))
            }
        } else {
          flowOf(UiState.Success(emptyList()))
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Loading,
      )

  fun clearFeedback() {
    _feedback.value = null
  }

  fun showMessage(message: String, isError: Boolean = false) {
    _feedback.value = FeedbackBanner(message = message, isError = isError)
  }

  fun selectModeFromHome(targetMode: AccountMode) {
    _secondaryRegistrationTarget.value = null
    _preferredMode.value = targetMode
  }

  fun switchOrActivateMode(targetMode: AccountMode, hasTargetProfile: Boolean) {
    val current = accountState.value
    if (
      targetMode == AccountMode.PASSAGEIRO &&
        current is AccountUiState.DriverReady &&
        current.profile.online &&
        isCloudSynced
    ) {
      viewModelScope.launch { repository.setDriverOnlineStatus(false) }
    }

    if (hasTargetProfile) {
      _secondaryRegistrationTarget.value = null
      _preferredMode.value = targetMode
      _feedback.value = FeedbackBanner("Alternado para Modo ${targetMode.labelPtBr}.")
    } else {
      _secondaryRegistrationTarget.value = targetMode
    }
  }

  fun cancelSecondaryRegistration() {
    _secondaryRegistrationTarget.value = null
    val current = accountState.value
    if (current is AccountUiState.NeedsRegistration && current.forcedMode != null) {
      _preferredMode.value =
        if (current.forcedMode == AccountMode.MOTORISTA) AccountMode.PASSAGEIRO
        else AccountMode.MOTORISTA
    }
  }

  private fun formatActionError(err: Throwable): String {
    return if (err is IllegalArgumentException || err is IllegalStateException) {
      err.message ?: toFriendlyPtBrErrorMessage(err)
    } else {
      toFriendlyPtBrErrorMessage(err)
    }
  }

  fun registerPassenger(fullName: String, phone: String) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.registerPassenger(fullName = fullName, phone = phone)
      _isBusy.value = false
      result
        .onSuccess {
          _secondaryRegistrationTarget.value = null
          _preferredMode.value = AccountMode.PASSAGEIRO
          _feedback.value = FeedbackBanner("Cadastro de Passageiro concluído com sucesso!")
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun registerDriver(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result =
        repository.registerDriver(
          fullName = fullName,
          phone = phone,
          vehicleModel = vehicleModel,
          vehiclePlate = vehiclePlate,
        )
      _isBusy.value = false
      result
        .onSuccess {
          _secondaryRegistrationTarget.value = null
          _preferredMode.value = AccountMode.MOTORISTA
          _feedback.value =
            FeedbackBanner("Cadastro de Motorista concluído! Fique online para receber pedidos.")
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun updatePassengerProfile(
    fullName: String,
    phone: String,
    onSaved: () -> Unit = {},
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.updatePassengerProfile(fullName = fullName, phone = phone)
      _isBusy.value = false
      result
        .onSuccess {
          val msg =
            if (isCloudSynced) "Perfil de Passageiro atualizado no Firestore!"
            else "Perfil de Passageiro atualizado na sessão atual!"
          _feedback.value = FeedbackBanner(msg)
          onSaved()
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun updateDriverProfile(
    fullName: String,
    phone: String,
    vehicleModel: String,
    vehiclePlate: String,
    onSaved: () -> Unit = {},
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result =
        repository.updateDriverProfile(
          fullName = fullName,
          phone = phone,
          vehicleModel = vehicleModel,
          vehiclePlate = vehiclePlate,
        )
      _isBusy.value = false
      result
        .onSuccess {
          val msg =
            if (isCloudSynced) "Perfil de Motorista atualizado no Firestore!"
            else "Perfil de Motorista atualizado na sessão atual!"
          _feedback.value = FeedbackBanner(msg)
          onSaved()
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun toggleDriverOnline(online: Boolean) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.setDriverOnlineStatus(online)
      _isBusy.value = false
      result
        .onSuccess {
          val statusMsg =
            if (online) "Você está ONLINE e recebendo chamados em tempo real."
            else "Você está OFFLINE. Novos chamados estão pausados."
          _feedback.value = FeedbackBanner(statusMsg)
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun createOrder(
    passengerName: String,
    serviceType: ServiceType,
    originAddress: String,
    destinationAddress: String,
    gpsLat: Double?,
    gpsLng: Double?,
    packageDescription: String,
    recipientName: String,
    paymentMethod: PaymentMethod,
    onCreatedSuccess: () -> Unit,
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val geo =
        FareCalculator.estimateCoordinatesFromAddresses(
          originAddress = originAddress,
          destinationAddress = destinationAddress,
          gpsLat = gpsLat,
          gpsLng = gpsLng,
        )
      val priceCents = FareCalculator.calculatePriceCents(serviceType, geo.distanceKm)
      val result =
        repository.createOrder(
          passengerName = passengerName,
          serviceType = serviceType,
          originAddress = originAddress,
          destinationAddress = destinationAddress,
          originLat = geo.originLat,
          originLng = geo.originLng,
          destLat = geo.destLat,
          destLng = geo.destLng,
          packageDescription = packageDescription,
          recipientName = recipientName,
          paymentMethod = paymentMethod,
          estimatedDistanceKm = geo.distanceKm,
          priceCents = priceCents,
        )
      _isBusy.value = false
      result
        .onSuccess {
          val msg =
            if (isCloudSynced) {
              "Solicitação salva no Firestore! Procurando motoristas online…"
            } else {
              "Pedido criado! Use o botão Voltar e abra Motorista para aceitar o chamado."
            }
          _feedback.value = FeedbackBanner(msg)
          onCreatedSuccess()
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun cancelPassengerOrder(orderId: String) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.cancelOrderByPassenger(orderId)
      _isBusy.value = false
      result
        .onSuccess { _feedback.value = FeedbackBanner("Solicitação cancelada.") }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun acceptOrder(
    orderId: String,
    driverProfile: DriverProfile,
    onAcceptedSuccess: () -> Unit,
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.acceptOrder(orderId, driverProfile)
      _isBusy.value = false
      result
        .onSuccess {
          _feedback.value = FeedbackBanner("Pedido aceito! Dirija-se ao endereço de origem.")
          onAcceptedSuccess()
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun declineOrder(orderId: String) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.declineOrder(orderId)
      _isBusy.value = false
      result
        .onSuccess { _feedback.value = FeedbackBanner("Chamado recusado e removido da sua fila.") }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  fun advanceOrderStatus(orderId: String, nextStatus: OrderStatus) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = repository.advanceOrderStatus(orderId, nextStatus)
      _isBusy.value = false
      result
        .onSuccess {
          val msg =
            when (nextStatus) {
              OrderStatus.A_CAMINHO -> "Status atualizado: A caminho da origem!"
              OrderStatus.EM_ANDAMENTO -> "Serviço iniciado! Boa viagem até o destino."
              OrderStatus.CONCLUIDO -> "Serviço concluído com sucesso! Ganhos registrados."
              else -> "Status do pedido atualizado."
            }
          _feedback.value = FeedbackBanner(msg)
        }
        .onFailure { err ->
          _feedback.value = FeedbackBanner(formatActionError(err), isError = true)
        }
    }
  }

  private companion object {
    const val TAG = "MobilityVM"
    const val STOP_TIMEOUT_MS = 5000L
  }
}
