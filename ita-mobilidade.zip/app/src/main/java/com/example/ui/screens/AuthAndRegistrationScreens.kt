package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.auth.isGoogleWebClientConfigured
import com.example.data.auth.signInWithGoogleInteractive
import com.example.data.model.AccountMode
import com.example.ui.components.GoogleAuthStatusDialog
import com.example.ui.components.TopFeedbackBar
import com.example.ui.viewmodel.FeedbackBanner
import com.google.firebase.FirebaseApp

@Composable
fun AuthScreen(
  onAuthSuccess: () -> Unit,
  onOpenPassenger: () -> Unit,
  onOpenDriver: () -> Unit,
  signedInEmail: String? = null,
  onSignOut: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }
  var isLoading by remember { mutableStateOf(false) }
  var activeSignInJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
  var errorMessage by rememberSaveable { mutableStateOf<String?>(null) }
  var dialogMessage by rememberSaveable { mutableStateOf<String?>(null) }

  val firebaseProjectId =
    remember {
      runCatching { FirebaseApp.getInstance().options.projectId.orEmpty() }.getOrDefault("")
    }
  val firestoreDbReady =
    remember(context) {
      runCatching { context.getString(R.string.firestore_database_id).isNotBlank() }
        .getOrDefault(false)
    }
  val googleClientReady = remember(context) { isGoogleWebClientConfigured(context) }

  if (dialogMessage != null) {
    GoogleAuthStatusDialog(
      message = dialogMessage.orEmpty(),
      onDismiss = { dialogMessage = null },
      onOpenPassenger = onOpenPassenger,
      onOpenDriver = onOpenDriver,
    )
  }

  Scaffold(
    contentWindowInsets = WindowInsets.safeDrawing,
    modifier = modifier.fillMaxSize().testTag("home_auth_screen"),
  ) { innerPadding ->
    Box(
      contentAlignment = Alignment.TopCenter,
      modifier =
        Modifier.fillMaxSize()
          .padding(innerPadding),
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .widthIn(max = 560.dp)
            .verticalScroll(rememberScrollState()),
      ) {
        // Hero Banner Header (visual preserved)
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .height(270.dp),
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_hero_banner_1793047212597),
            contentDescription = stringResource(R.string.hero_banner_content_desc),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier =
              Modifier.fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    colors =
                      listOf(
                        MaterialTheme.colorScheme.background.copy(alpha = 0.10f),
                        MaterialTheme.colorScheme.background.copy(alpha = 0.95f),
                      )
                  )
                )
          )
          Surface(
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.align(Alignment.TopStart).padding(20.dp),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.TwoWheeler,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.labelLarge,
              )
            }
          }

          Column(
            modifier =
              Modifier.align(Alignment.BottomStart)
                .padding(horizontal = 24.dp, vertical = 16.dp),
          ) {
            Text(
              text = stringResource(R.string.auth_headline),
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onBackground,
            )
          }
        }

        Column(
          verticalArrangement = Arrangement.spacedBy(16.dp),
          modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
        ) {
          Text(
            text = stringResource(R.string.auth_subtitle),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          // Interactive Dual Mode Cards (Passageiro & Motorista open their respective screens)
          Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            FeatureHighlightCard(
              title = "Passageiro",
              description = "Corridas de moto e envio de pequenos pacotes",
              ctaLabel = stringResource(R.string.home_open_passenger_cta),
              icon = Icons.Filled.Person,
              onClick = onOpenPassenger,
              modifier = Modifier.weight(1f).testTag("home_passenger_button"),
            )
            FeatureHighlightCard(
              title = "Motorista",
              description = "Chamados em tempo real e controle de ganhos",
              ctaLabel = stringResource(R.string.home_open_driver_cta),
              icon = Icons.Filled.TwoWheeler,
              onClick = onOpenDriver,
              modifier = Modifier.weight(1f).testTag("home_driver_button"),
            )
          }

          if (errorMessage != null) {
            TopFeedbackBar(
              feedback = FeedbackBanner(message = errorMessage.orEmpty(), isError = true),
              onDismiss = { errorMessage = null },
            )
          }

          if (signedInEmail != null) {
            Surface(
              color = MaterialTheme.colorScheme.primaryContainer,
              contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
              shape = MaterialTheme.shapes.medium,
              modifier = Modifier.fillMaxWidth().testTag("signed_in_account_card"),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.weight(1f),
                ) {
                  Icon(
                    imageVector = Icons.Filled.CloudDone,
                    contentDescription = "Conectado ao Firebase",
                    modifier = Modifier.size(20.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = "Conectado ao Firebase",
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                    )
                    if (signedInEmail.isNotBlank()) {
                      Text(
                        text = signedInEmail,
                        style = MaterialTheme.typography.bodySmall,
                      )
                    }
                  }
                }
                if (onSignOut != null) {
                  OutlinedButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("home_sign_out_button"),
                  ) {
                    Text("Sair")
                  }
                }
              }
            }
          } else {
            Button(
              onClick = {
                isLoading = true
                errorMessage = null
                dialogMessage = null
                activeSignInJob =
                  signInWithGoogleInteractive(
                    context = context,
                    credentialManager = credentialManager,
                    scope = scope,
                    onAuthSuccess = {
                      isLoading = false
                      activeSignInJob = null
                      onAuthSuccess()
                    },
                    onAuthError = { msg ->
                      isLoading = false
                      activeSignInJob = null
                      errorMessage = msg
                      dialogMessage = msg
                    },
                    onAuthCancelled = {
                      isLoading = false
                      activeSignInJob = null
                      val cancelMsg =
                        "O seletor de contas do Google foi fechado ou não há conta Google conectada neste emulador. Adicione uma conta Google nas Configurações do Android para sincronizar na nuvem, ou toque nos botões Passageiro e Motorista para usar o aplicativo agora."
                      errorMessage = cancelMsg
                      dialogMessage = cancelMsg
                    },
                  )
              },
              enabled = !isLoading,
              modifier =
                Modifier.fillMaxWidth()
                  .height(54.dp)
                  .testTag("google_sign_in_button"),
            ) {
              if (isLoading) {
                CircularProgressIndicator(
                  color = MaterialTheme.colorScheme.onPrimary,
                  strokeWidth = 2.dp,
                  modifier = Modifier.size(22.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = stringResource(R.string.auth_loading))
              } else {
                Text(
                  text = stringResource(R.string.auth_google_button),
                  style = MaterialTheme.typography.titleMedium,
                )
              }
            }
            if (isLoading) {
              OutlinedButton(
                onClick = {
                  activeSignInJob?.cancel()
                  activeSignInJob = null
                  isLoading = false
                  val msg =
                    "Tentativa de login cancelada. Se o emulador não possuir conta Google configurada, use os botões Passageiro ou Motorista acima."
                  errorMessage = msg
                  dialogMessage = msg
                },
                modifier = Modifier.fillMaxWidth().testTag("cancel_google_sign_in_button"),
              ) {
                Text("Cancelar tentativa de login")
              }
            }
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.CloudDone,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(16.dp),
            )
            Text(
              text =
                if (firestoreDbReady && googleClientReady && firebaseProjectId.isNotBlank()) {
                  "${stringResource(R.string.auth_security_note)} (Projeto $firebaseProjectId ativo)"
                } else {
                  stringResource(R.string.auth_security_note)
                },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Spacer(modifier = Modifier.height(16.dp))
        }
      }
    }
  }
}

@Composable
private fun FeatureHighlightCard(
  title: String,
  description: String,
  ctaLabel: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    onClick = onClick,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f)
      ),
    shape = MaterialTheme.shapes.medium,
    modifier = modifier,
  ) {
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(14.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(24.dp),
      )
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
      ) {
        Text(
          text = ctaLabel,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.Bold,
        )
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = ctaLabel,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(16.dp),
        )
      }
    }
  }
}

@Composable
fun RegistrationScreen(
  suggestedName: String,
  userEmail: String,
  isBusy: Boolean,
  feedback: FeedbackBanner?,
  onDismissFeedback: () -> Unit,
  onRegisterPassenger: (fullName: String, phone: String) -> Unit,
  onRegisterDriver: (fullName: String, phone: String, model: String, plate: String) -> Unit,
  onSignOut: () -> Unit,
  onNavigateBack: () -> Unit,
  forcedMode: AccountMode? = null,
  onCancelSecondaryRegistration: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val backAction: () -> Unit = onCancelSecondaryRegistration ?: onNavigateBack
  BackHandler(onBack = backAction)

  var selectedMode by
    rememberSaveable(forcedMode) { mutableStateOf(forcedMode ?: AccountMode.PASSAGEIRO) }
  var fullName by rememberSaveable { mutableStateOf(suggestedName) }
  var phone by rememberSaveable { mutableStateOf("") }
  var vehicleModel by rememberSaveable { mutableStateOf("") }
  var vehiclePlate by rememberSaveable { mutableStateOf("") }

  Scaffold(
    contentWindowInsets = WindowInsets.safeDrawing,
    modifier = modifier.fillMaxSize().testTag("registration_screen"),
  ) { innerPadding ->
    Box(
      contentAlignment = Alignment.TopCenter,
      modifier = Modifier.fillMaxSize().padding(innerPadding),
    ) {
      Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier =
          Modifier.fillMaxWidth()
            .widthIn(max = 580.dp)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
          ) {
            IconButton(
              onClick = backAction,
              modifier = Modifier.testTag("navigate_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.navigate_back_action),
              )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(
                text = stringResource(R.string.register_title),
                style = MaterialTheme.typography.headlineMedium,
              )
              if (userEmail.isNotBlank()) {
                Text(
                  text = "Conta conectada: $userEmail",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }
          OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier.testTag("registration_sign_out_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Logout,
              contentDescription = stringResource(R.string.sign_out_action),
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Sair")
          }
        }

        Text(
          text = stringResource(R.string.register_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        TopFeedbackBar(feedback = feedback, onDismiss = onDismissFeedback)

        if (forcedMode == null) {
          // Role Selection Cards
          Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            RoleChoiceCard(
              title = stringResource(R.string.role_passenger_title),
              description = stringResource(R.string.role_passenger_desc),
              selected = selectedMode == AccountMode.PASSAGEIRO,
              icon = Icons.Filled.LocalShipping,
              onClick = { selectedMode = AccountMode.PASSAGEIRO },
              modifier = Modifier.weight(1f).testTag("select_role_passenger"),
            )
            RoleChoiceCard(
              title = stringResource(R.string.role_driver_title),
              description = stringResource(R.string.role_driver_desc),
              selected = selectedMode == AccountMode.MOTORISTA,
              icon = Icons.Filled.TwoWheeler,
              onClick = { selectedMode = AccountMode.MOTORISTA },
              modifier = Modifier.weight(1f).testTag("select_role_driver"),
            )
          }
        } else {
          RoleChoiceCard(
            title =
              if (forcedMode == AccountMode.PASSAGEIRO) stringResource(R.string.role_passenger_title)
              else stringResource(R.string.role_driver_title),
            description =
              if (forcedMode == AccountMode.PASSAGEIRO) stringResource(R.string.role_passenger_desc)
              else stringResource(R.string.role_driver_desc),
            selected = true,
            icon =
              if (forcedMode == AccountMode.PASSAGEIRO) Icons.Filled.LocalShipping
              else Icons.Filled.TwoWheeler,
            onClick = {},
            modifier = Modifier.fillMaxWidth(),
          )
        }

        OutlinedTextField(
          value = fullName,
          onValueChange = { fullName = it },
          label = { Text(stringResource(R.string.field_full_name)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
          modifier = Modifier.fillMaxWidth().testTag("register_name_input"),
        )

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text(stringResource(R.string.field_phone)) },
          placeholder = { Text("Ex.: (12) 99123-4567") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          modifier = Modifier.fillMaxWidth().testTag("register_phone_input"),
        )

        if (selectedMode == AccountMode.MOTORISTA) {
          OutlinedTextField(
            value = vehicleModel,
            onValueChange = { vehicleModel = it },
            label = { Text(stringResource(R.string.field_vehicle_model)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            modifier = Modifier.fillMaxWidth().testTag("register_vehicle_model_input"),
          )

          OutlinedTextField(
            value = vehiclePlate,
            onValueChange = { vehiclePlate = it.uppercase().take(10) },
            label = { Text(stringResource(R.string.field_vehicle_plate)) },
            singleLine = true,
            keyboardOptions =
              KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth().testTag("register_vehicle_plate_input"),
          )
        }

        Button(
          onClick = {
            if (selectedMode == AccountMode.PASSAGEIRO) {
              onRegisterPassenger(fullName, phone)
            } else {
              onRegisterDriver(fullName, phone, vehicleModel, vehiclePlate)
            }
          },
          enabled = !isBusy,
          modifier =
            Modifier.fillMaxWidth()
              .height(54.dp)
              .testTag("submit_registration_button"),
        ) {
          if (isBusy) {
            CircularProgressIndicator(
              color = MaterialTheme.colorScheme.onPrimary,
              strokeWidth = 2.dp,
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
          }
          Text(
            text =
              if (selectedMode == AccountMode.PASSAGEIRO) {
                stringResource(R.string.register_submit_passenger)
              } else {
                stringResource(R.string.register_submit_driver)
              },
            style = MaterialTheme.typography.titleMedium,
          )
        }

        OutlinedButton(
          onClick = backAction,
          enabled = !isBusy,
          modifier =
            Modifier.fillMaxWidth()
              .height(48.dp)
              .testTag("cancel_secondary_registration_button"),
        ) {
          Text(
            if (onCancelSecondaryRegistration != null) "Voltar ao perfil atual"
            else "Voltar para a tela inicial"
          )
        }
      }
    }
  }
}

@Composable
private fun RoleChoiceCard(
  title: String,
  description: String,
  selected: Boolean,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val borderColor =
    if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
  val bgColor =
    if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    else MaterialTheme.colorScheme.surface

  Card(
    border = BorderStroke(width = if (selected) 2.dp else 1.dp, color = borderColor),
    colors = CardDefaults.cardColors(containerColor = bgColor),
    shape = MaterialTheme.shapes.large,
    modifier = modifier.clickable(onClick = onClick),
  ) {
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(16.dp),
    ) {
      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(26.dp),
        )
        if (selected) {
          Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = "Selecionado",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
          )
        }
      }
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
