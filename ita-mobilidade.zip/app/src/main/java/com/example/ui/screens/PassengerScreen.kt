package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.auth.signInWithGoogleInteractive
import com.example.data.location.LocationAndMapsHelper
import com.example.data.model.AccountMode
import com.example.data.model.FareCalculator
import com.example.data.model.OrderStatus
import com.example.data.model.PassengerProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.ServiceOrder
import com.example.data.model.ServiceType
import com.example.data.payment.PaymentGatewayService
import com.example.ui.components.GoogleAuthStatusDialog
import com.example.ui.components.IntegrationStatusDialog
import com.example.ui.components.InteractiveRouteMapCard
import com.example.ui.components.LocalSessionCloudBanner
import com.example.ui.components.OrderStatusStepper
import com.example.ui.components.ProfileAndModeDialog
import com.example.ui.components.TopFeedbackBar
import com.example.ui.viewmodel.FeedbackBanner
import com.example.ui.viewmodel.MobilityViewModel
import com.example.ui.viewmodel.UiState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassengerHomeScreen(
  profile: PassengerProfile,
  hasDriverProfile: Boolean,
  ordersState: UiState<List<ServiceOrder>>,
  isBusy: Boolean,
  feedback: FeedbackBanner?,
  viewModel: MobilityViewModel,
  onNavigateBack: () -> Unit,
  onSwitchToDriverMode: () -> Unit,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  var selectedTab by rememberSaveable { mutableIntStateOf(0) }
  var showIntegrationsDialog by rememberSaveable { mutableStateOf(false) }
  var showProfileDialog by rememberSaveable { mutableStateOf(false) }
  var isSigningInCloud by remember { mutableStateOf(false) }
  var googleAuthDialogMessage by rememberSaveable { mutableStateOf<String?>(null) }

  BackHandler {
    if (selectedTab != 0) {
      selectedTab = 0
    } else {
      onNavigateBack()
    }
  }

  val ordersList = (ordersState as? UiState.Success)?.data.orEmpty()
  val activeOrder = remember(ordersList) { ordersList.firstOrNull { it.typedStatus.isActive } }

  if (googleAuthDialogMessage != null) {
    GoogleAuthStatusDialog(
      message = googleAuthDialogMessage.orEmpty(),
      onDismiss = { googleAuthDialogMessage = null },
    )
  }

  if (showIntegrationsDialog) {
    IntegrationStatusDialog(onDismiss = { showIntegrationsDialog = false })
  }

  if (showProfileDialog) {
    ProfileAndModeDialog(
      currentMode = AccountMode.PASSAGEIRO,
      passengerProfile = profile,
      driverProfile = null,
      hasOtherProfile = hasDriverProfile,
      isBusy = isBusy,
      isCloudSynced = viewModel.isCloudSynced,
      onSavePassenger = { name, phone ->
        viewModel.updatePassengerProfile(
          fullName = name,
          phone = phone,
          onSaved = { showProfileDialog = false },
        )
      },
      onSaveDriver = { _, _, _, _ -> },
      onSwitchOrActivateOtherMode = {
        onSwitchToDriverMode()
        viewModel.switchOrActivateMode(
          targetMode = AccountMode.MOTORISTA,
          hasTargetProfile = hasDriverProfile,
        )
      },
      onDismiss = { showProfileDialog = false },
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize().testTag("passenger_home_screen")) {
    val isExpanded = maxWidth >= 700.dp

    Scaffold(
      contentWindowInsets = WindowInsets.safeDrawing,
      topBar = {
        TopAppBar(
          navigationIcon = {
            IconButton(
              onClick = onNavigateBack,
              modifier = Modifier.testTag("navigate_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.navigate_back_action),
              )
            }
          },
          title = {
            Column {
              Text(text = stringResource(R.string.app_name))
              Text(
                text = "Modo Passageiro • ${profile.fullName}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          },
          actions = {
            IconButton(
              onClick = { showProfileDialog = true },
              modifier = Modifier.testTag("passenger_profile_mode_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.AccountCircle,
                contentDescription = stringResource(R.string.nav_profile_and_mode),
              )
            }
            IconButton(
              onClick = { showIntegrationsDialog = true },
              modifier = Modifier.testTag("passenger_integrations_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Info,
                contentDescription = stringResource(R.string.nav_integrations_info),
              )
            }
            if (viewModel.isCloudSynced) {
              IconButton(
                onClick = onSignOut,
                modifier = Modifier.testTag("passenger_sign_out_button"),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Logout,
                  contentDescription = stringResource(R.string.sign_out_action),
                )
              }
            }
          },
        )
      },
      bottomBar = {
        if (!isExpanded) {
          NavigationBar {
            NavigationBarItem(
              selected = selectedTab == 0,
              onClick = { selectedTab = 0 },
              icon = {
                Icon(
                  imageVector = Icons.Filled.TwoWheeler,
                  contentDescription = stringResource(R.string.nav_passenger_request),
                )
              },
              label = { Text(stringResource(R.string.nav_passenger_request)) },
              modifier = Modifier.testTag("passenger_tab_request"),
            )
            NavigationBarItem(
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              icon = {
                BadgedBox(
                  badge = {
                    if (activeOrder != null) {
                      Badge { Text("1") }
                    }
                  }
                ) {
                  Icon(
                    imageVector = Icons.Filled.Schedule,
                    contentDescription = stringResource(R.string.nav_passenger_active),
                  )
                }
              },
              label = { Text(stringResource(R.string.nav_passenger_active)) },
              modifier = Modifier.testTag("passenger_tab_active"),
            )
            NavigationBarItem(
              selected = selectedTab == 2,
              onClick = { selectedTab = 2 },
              icon = {
                Icon(
                  imageVector = Icons.Filled.History,
                  contentDescription = stringResource(R.string.nav_passenger_history),
                )
              },
              label = { Text(stringResource(R.string.nav_passenger_history)) },
              modifier = Modifier.testTag("passenger_tab_history"),
            )
          }
        }
      },
    ) { innerPadding ->
      Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        if (isExpanded) {
          NavigationRail(modifier = Modifier.fillMaxHeight()) {
            NavigationRailItem(
              selected = selectedTab == 0,
              onClick = { selectedTab = 0 },
              icon = { Icon(Icons.Filled.TwoWheeler, contentDescription = null) },
              label = { Text(stringResource(R.string.nav_passenger_request)) },
            )
            NavigationRailItem(
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              icon = { Icon(Icons.Filled.Schedule, contentDescription = null) },
              label = { Text(stringResource(R.string.nav_passenger_active)) },
            )
            NavigationRailItem(
              selected = selectedTab == 2,
              onClick = { selectedTab = 2 },
              icon = { Icon(Icons.Filled.History, contentDescription = null) },
              label = { Text(stringResource(R.string.nav_passenger_history)) },
            )
          }
        }

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        ) {
          if (!viewModel.isCloudSynced && feedback == null) {
            LocalSessionCloudBanner(
              isSigningIn = isSigningInCloud,
              onConnectGoogleClick = {
                isSigningInCloud = true
                signInWithGoogleInteractive(
                  context = context,
                  credentialManager = credentialManager,
                  scope = scope,
                  onAuthSuccess = { isSigningInCloud = false },
                  onAuthError = { msg ->
                    isSigningInCloud = false
                    googleAuthDialogMessage = msg
                  },
                  onAuthCancelled = {
                    isSigningInCloud = false
                    googleAuthDialogMessage =
                      "O seletor de contas do Google foi fechado ou não há conta Google conectada neste emulador. Você pode continuar usando o Modo Passageiro normalmente nesta sessão."
                  },
                )
              },
              modifier = Modifier.widthIn(max = 680.dp),
            )
          }

          TopFeedbackBar(
            feedback = feedback,
            onDismiss = viewModel::clearFeedback,
            modifier = Modifier.widthIn(max = 680.dp),
          )

          Box(modifier = Modifier.fillMaxSize().widthIn(max = 680.dp)) {
            when (selectedTab) {
              0 ->
                PassengerRequestTab(
                  profile = profile,
                  activeOrder = activeOrder,
                  isBusy = isBusy,
                  viewModel = viewModel,
                  onNavigateToActive = { selectedTab = 1 },
                )
              1 ->
                PassengerActiveOrderTab(
                  activeOrder = activeOrder,
                  ordersState = ordersState,
                  isBusy = isBusy,
                  onCancelOrder = viewModel::cancelPassengerOrder,
                  onShowMapError = { msg -> viewModel.showMessage(msg, isError = true) },
                  onGoToRequest = { selectedTab = 0 },
                )
              else ->
                PassengerHistoryTab(
                  ordersState = ordersState,
                )
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PassengerRequestTab(
  profile: PassengerProfile,
  activeOrder: ServiceOrder?,
  isBusy: Boolean,
  viewModel: MobilityViewModel,
  onNavigateToActive: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  var selectedService by rememberSaveable { mutableStateOf(ServiceType.CORRIDA_MOTO) }
  var originAddress by rememberSaveable { mutableStateOf("") }
  var destinationAddress by rememberSaveable { mutableStateOf("") }
  var gpsLat by rememberSaveable { mutableStateOf<Double?>(null) }
  var gpsLng by rememberSaveable { mutableStateOf<Double?>(null) }
  var isFetchingGps by remember { mutableStateOf(false) }
  var packageDesc by rememberSaveable { mutableStateOf("") }
  var recipientName by rememberSaveable { mutableStateOf("") }
  var selectedPayment by rememberSaveable { mutableStateOf(PaymentMethod.PIX) }

  val locationPermissionLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
      val granted =
        grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
          grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
      if (granted) {
        scope.launch {
          isFetchingGps = true
          LocationAndMapsHelper.fetchCurrentGpsOrigin(context)
            .onSuccess { gps ->
              originAddress = gps.formattedAddress
              gpsLat = gps.latitude
              gpsLng = gps.longitude
            }
            .onFailure { err ->
              viewModel.showMessage(err.message ?: "GPS indisponível.", isError = true)
            }
          isFetchingGps = false
        }
      } else {
        viewModel.showMessage(
          "Permissão de localização recusada. Digite o endereço de origem manualmente.",
          isError = true,
        )
      }
    }

  val geoPreview =
    remember(originAddress, destinationAddress, gpsLat, gpsLng) {
      FareCalculator.estimateCoordinatesFromAddresses(
        originAddress = originAddress.ifBlank { "Origem" },
        destinationAddress = destinationAddress.ifBlank { "Destino" },
        gpsLat = gpsLat,
        gpsLng = gpsLng,
      )
    }
  val pricePreviewCents =
    remember(selectedService, geoPreview.distanceKm) {
      FareCalculator.calculatePriceCents(selectedService, geoPreview.distanceKm)
    }
  val paymentNotice =
    remember(selectedPayment) { PaymentGatewayService.noticeForMethod(selectedPayment) }

  Column(
    verticalArrangement = Arrangement.spacedBy(16.dp),
    modifier =
      Modifier.fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
  ) {
    if (activeOrder != null) {
      Card(
        colors =
          CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier =
          Modifier.fillMaxWidth()
            .clickable(onClick = onNavigateToActive)
            .testTag("active_order_shortcut_card"),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(16.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.TwoWheeler,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Você possui um pedido ativo: ${activeOrder.typedStatus.labelPtBr}",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
              text = "Toque para acompanhar o motorista em tempo real.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
          }
        }
      }
    }

    // Service Type Cards
    Text(
      text = "Escolha o tipo de serviço",
      style = MaterialTheme.typography.titleMedium,
    )
    Row(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      ServiceTypeCard(
        title = stringResource(R.string.service_ride_title),
        subtitle = stringResource(R.string.service_ride_subtitle),
        selected = selectedService == ServiceType.CORRIDA_MOTO,
        icon = Icons.Filled.TwoWheeler,
        onClick = { selectedService = ServiceType.CORRIDA_MOTO },
        modifier = Modifier.weight(1f).testTag("select_service_ride"),
      )
      ServiceTypeCard(
        title = stringResource(R.string.service_package_title),
        subtitle = stringResource(R.string.service_package_subtitle),
        selected = selectedService == ServiceType.ENTREGA_PACOTE,
        icon = Icons.Filled.LocalShipping,
        onClick = { selectedService = ServiceType.ENTREGA_PACOTE },
        modifier = Modifier.weight(1f).testTag("select_service_package"),
      )
    }

    // Origin & GPS
    OutlinedTextField(
      value = originAddress,
      onValueChange = {
        originAddress = it
        gpsLat = null
        gpsLng = null
      },
      label = { Text(stringResource(R.string.field_origin)) },
      placeholder = { Text("Ex.: Praça Afonso Pena, 120 - Centro") },
      trailingIcon = {
        IconButton(
          onClick = {
            if (LocationAndMapsHelper.hasLocationPermission(context)) {
              scope.launch {
                isFetchingGps = true
                LocationAndMapsHelper.fetchCurrentGpsOrigin(context)
                  .onSuccess { gps ->
                    originAddress = gps.formattedAddress
                    gpsLat = gps.latitude
                    gpsLng = gps.longitude
                  }
                  .onFailure { err ->
                    viewModel.showMessage(err.message ?: "GPS indisponível.", isError = true)
                  }
                isFetchingGps = false
              }
            } else {
              locationPermissionLauncher.launch(
                arrayOf(
                  Manifest.permission.ACCESS_FINE_LOCATION,
                  Manifest.permission.ACCESS_COARSE_LOCATION,
                )
              )
            }
          },
          modifier = Modifier.testTag("use_gps_button"),
        ) {
          if (isFetchingGps) {
            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
          } else {
            Icon(
              imageVector = Icons.Filled.MyLocation,
              contentDescription = stringResource(R.string.use_my_gps),
              tint = MaterialTheme.colorScheme.primary,
            )
          }
        }
      },
      modifier = Modifier.fillMaxWidth().testTag("origin_input"),
    )

    OutlinedTextField(
      value = destinationAddress,
      onValueChange = { destinationAddress = it },
      label = { Text(stringResource(R.string.field_destination)) },
      placeholder = { Text("Ex.: Portaria Principal ITA - Vila das Acácias") },
      modifier = Modifier.fillMaxWidth().testTag("destination_input"),
    )

    // Quick urban suggestions for fast testing
    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      val suggestions =
        listOf(
          "Centro - Av. Nelson D'Ávila, 400",
          "Portaria ITA - Vila das Acácias",
          "Terminal Rodoviário Central",
          "Shopping CenterVale",
        )
      suggestions.forEach { place ->
        SuggestionChip(
          onClick = {
            if (originAddress.isBlank()) originAddress = place else destinationAddress = place
          },
          label = { Text(place, style = MaterialTheme.typography.labelSmall) },
        )
      }
    }

    if (selectedService == ServiceType.ENTREGA_PACOTE) {
      OutlinedTextField(
        value = packageDesc,
        onValueChange = { packageDesc = it },
        label = { Text(stringResource(R.string.field_package_desc)) },
        modifier = Modifier.fillMaxWidth().testTag("package_description_input"),
      )
      OutlinedTextField(
        value = recipientName,
        onValueChange = { recipientName = it },
        label = { Text(stringResource(R.string.field_recipient_name)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("recipient_name_input"),
      )
    }

    // Payment Method Selection
    Text(
      text = stringResource(R.string.payment_section_title),
      style = MaterialTheme.typography.titleMedium,
    )
    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      PaymentMethod.entries.forEach { method ->
        val icon =
          when (method) {
            PaymentMethod.PIX -> Icons.Filled.QrCode
            PaymentMethod.DINHEIRO -> Icons.Filled.Payments
            PaymentMethod.CARTAO -> Icons.Filled.CreditCard
          }
        FilterChip(
          selected = selectedPayment == method,
          onClick = { selectedPayment = method },
          leadingIcon = {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
          },
          label = { Text(method.labelPtBr) },
          modifier = Modifier.weight(1f).testTag("payment_chip_${method.code.lowercase()}"),
        )
      }
    }

    // Transparent Payment Provider Notice (Never simulates fake online charges)
    Surface(
      color = MaterialTheme.colorScheme.surfaceVariant,
      shape = MaterialTheme.shapes.medium,
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.padding(12.dp),
      ) {
        Text(
          text = "${selectedPayment.labelPtBr} • ${paymentNotice.badgeLabelPtBr}",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
        )
        Text(
          text = paymentNotice.explanationPtBr,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }

    InteractiveRouteMapCard(
      originAddress = originAddress,
      destinationAddress = destinationAddress,
      originLat = geoPreview.originLat,
      originLng = geoPreview.originLng,
      destLat = geoPreview.destLat,
      destLng = geoPreview.destLng,
      distanceKm = geoPreview.distanceKm,
      priceCents = pricePreviewCents,
      onMapError = { msg -> viewModel.showMessage(msg, isError = true) },
    )

    Button(
      onClick = {
        viewModel.createOrder(
          passengerName = profile.fullName,
          serviceType = selectedService,
          originAddress = originAddress,
          destinationAddress = destinationAddress,
          gpsLat = gpsLat,
          gpsLng = gpsLng,
          packageDescription = packageDesc,
          recipientName = recipientName,
          paymentMethod = selectedPayment,
          onCreatedSuccess = {
            packageDesc = ""
            recipientName = ""
            onNavigateToActive()
          },
        )
      },
      enabled = !isBusy,
      modifier =
        Modifier.fillMaxWidth()
          .height(54.dp)
          .testTag("submit_order_button"),
    ) {
      if (isBusy) {
        CircularProgressIndicator(
          color = MaterialTheme.colorScheme.onPrimary,
          strokeWidth = 2.dp,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
      } else {
        Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
      }
      Text(
        text =
          "${stringResource(R.string.submit_order_button)} • ${FareCalculator.formatCurrencyBrl(pricePreviewCents)}",
        style = MaterialTheme.typography.titleMedium,
      )
    }

    Spacer(modifier = Modifier.height(12.dp))
  }
}

@Composable
private fun ServiceTypeCard(
  title: String,
  subtitle: String,
  selected: Boolean,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    border =
      BorderStroke(
        width = if (selected) 2.dp else 1.dp,
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
      ),
    colors =
      CardDefaults.cardColors(
        containerColor =
          if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
          else MaterialTheme.colorScheme.surface
      ),
    shape = MaterialTheme.shapes.large,
    modifier = modifier.clickable(onClick = onClick),
  ) {
    Column(
      verticalArrangement = Arrangement.spacedBy(6.dp),
      modifier = Modifier.padding(14.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(26.dp),
      )
      Text(text = title, style = MaterialTheme.typography.titleMedium)
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun PassengerActiveOrderTab(
  activeOrder: ServiceOrder?,
  ordersState: UiState<List<ServiceOrder>>,
  isBusy: Boolean,
  onCancelOrder: (String) -> Unit,
  onShowMapError: (String) -> Unit,
  onGoToRequest: () -> Unit,
) {
  if (ordersState is UiState.Loading) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
      CircularProgressIndicator()
    }
    return
  }

  if (activeOrder == null) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.fillMaxSize().padding(32.dp),
    ) {
      Icon(
        imageVector = Icons.Filled.TwoWheeler,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(56.dp),
      )
      Spacer(modifier = Modifier.height(12.dp))
      Text(
        text = "Nenhum pedido em andamento",
        style = MaterialTheme.typography.titleLarge,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Solicite uma corrida de moto ou entrega de pacote para acompanhar aqui em tempo real.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(modifier = Modifier.height(20.dp))
      Button(
        onClick = onGoToRequest,
        modifier = Modifier.testTag("empty_active_go_to_request_button"),
      ) {
        Text("Solicitar agora")
      }
    }
    return
  }

  Column(
    verticalArrangement = Arrangement.spacedBy(16.dp),
    modifier =
      Modifier.fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
  ) {
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(16.dp),
      ) {
        Row(
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = activeOrder.typedService.labelPtBr,
            style = MaterialTheme.typography.titleLarge,
          )
          Text(
            text = FareCalculator.formatCurrencyBrl(activeOrder.priceCents),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
          )
        }

        if (activeOrder.typedService == ServiceType.ENTREGA_PACOTE) {
          Text(
            text =
              "Pacote: ${activeOrder.packageDescription}" +
                if (activeOrder.recipientName.isNotBlank()) " • Destinatário: ${activeOrder.recipientName}" else "",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.tertiary,
          )
        }

        Text(
          text = "Pagamento: ${activeOrder.typedPaymentMethod.labelPtBr} (${activeOrder.typedPaymentStatus.labelPtBr})",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        HorizontalDivider()
        OrderStatusStepper(currentStatus = activeOrder.typedStatus)
      }
    }

    // Driver Info Card
    Card(
      colors =
        CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f)
        ),
      modifier = Modifier.fillMaxWidth().testTag("passenger_driver_info_card"),
    ) {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(16.dp),
      ) {
        Text(
          text = "Informações do Motorista",
          style = MaterialTheme.typography.titleMedium,
        )
        if (activeOrder.driverId.isBlank()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Aguardando um motorista parceiro online aceitar sua solicitação…",
              style = MaterialTheme.typography.bodyMedium,
            )
          }
        } else {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(
                imageVector = Icons.Filled.Person,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp),
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = activeOrder.driverName,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  text = activeOrder.driverVehicleModel,
                  style = MaterialTheme.typography.bodyMedium,
                )
              }
            }
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = MaterialTheme.shapes.small,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              Text(
                text = activeOrder.driverVehiclePlate,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              )
            }
          }
        }
      }
    }

    InteractiveRouteMapCard(
      originAddress = activeOrder.originAddress,
      destinationAddress = activeOrder.destinationAddress,
      originLat = activeOrder.originLat,
      originLng = activeOrder.originLng,
      destLat = activeOrder.destLat,
      destLng = activeOrder.destLng,
      distanceKm = activeOrder.estimatedDistanceKm,
      priceCents = activeOrder.priceCents,
      onMapError = onShowMapError,
    )

    if (activeOrder.typedStatus == OrderStatus.SOLICITADO) {
      OutlinedButton(
        onClick = { onCancelOrder(activeOrder.id) },
        enabled = !isBusy,
        colors =
          ButtonDefaults.outlinedButtonColors(
            contentColor = MaterialTheme.colorScheme.error
          ),
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("cancel_order_button"),
      ) {
        Text(text = stringResource(R.string.cancel_order_button))
      }
    }
  }
}

@Composable
private fun PassengerHistoryTab(
  ordersState: UiState<List<ServiceOrder>>,
) {
  when (ordersState) {
    is UiState.Loading -> {
      Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        CircularProgressIndicator()
      }
    }
    is UiState.Error -> {
      Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Text(text = ordersState.message, color = MaterialTheme.colorScheme.error)
      }
    }
    is UiState.Success -> {
      if (ordersState.data.isEmpty()) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
          modifier = Modifier.fillMaxSize().padding(32.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.History,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(52.dp),
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = stringResource(R.string.empty_passenger_history_title),
            style = MaterialTheme.typography.titleLarge,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = stringResource(R.string.empty_passenger_history_desc),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      } else {
        LazyColumn(
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxSize().testTag("passenger_history_list"),
        ) {
          items(ordersState.data, key = { it.id }) { order ->
            OrderHistoryCard(order = order, showDriverInfo = true)
          }
        }
      }
    }
  }
}

@Composable
fun OrderHistoryCard(
  order: ServiceOrder,
  showDriverInfo: Boolean,
  modifier: Modifier = Modifier,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = modifier.fillMaxWidth().testTag("history_order_card_${order.id}"),
  ) {
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(16.dp),
    ) {
      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector =
              if (order.typedService == ServiceType.CORRIDA_MOTO) Icons.Filled.TwoWheeler
              else Icons.Filled.LocalShipping,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = order.typedService.labelPtBr,
            style = MaterialTheme.typography.titleMedium,
          )
        }
        Text(
          text = FareCalculator.formatCurrencyBrl(order.priceCents),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.Bold,
        )
      }

      Text(
        text = "De: ${order.originAddress}",
        style = MaterialTheme.typography.bodySmall,
      )
      Text(
        text = "Para: ${order.destinationAddress}",
        style = MaterialTheme.typography.bodySmall,
      )
      if (order.typedService == ServiceType.ENTREGA_PACOTE && order.packageDescription.isNotBlank()) {
        Text(
          text = "Pacote: ${order.packageDescription}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.tertiary,
        )
      }

      HorizontalDivider()

      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text =
            "${order.typedStatus.labelPtBr} • ${order.typedPaymentMethod.labelPtBr}",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = FareCalculator.formatTimestampPtBr(order.updatedAt ?: order.createdAt),
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      if (showDriverInfo && order.driverName.isNotBlank()) {
        Text(
          text =
            "Motorista: ${order.driverName} (${order.driverVehicleModel} • ${order.driverVehiclePlate})",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary,
        )
      } else if (!showDriverInfo) {
        Text(
          text = "Passageiro: ${order.passengerName}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary,
        )
      }
    }
  }
}
