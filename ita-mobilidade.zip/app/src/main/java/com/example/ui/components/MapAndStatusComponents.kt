package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.location.LocationAndMapsHelper
import com.example.data.model.FareCalculator
import com.example.data.model.OrderStatus
import com.example.data.payment.PaymentGatewayService
import com.example.ui.viewmodel.FeedbackBanner
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.auth
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState

@Composable
fun TopFeedbackBar(
  feedback: FeedbackBanner?,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  AnimatedVisibility(visible = feedback != null, modifier = modifier) {
    val current = feedback ?: return@AnimatedVisibility
    val containerColor =
      if (current.isError) MaterialTheme.colorScheme.errorContainer
      else MaterialTheme.colorScheme.primaryContainer
    val contentColor =
      if (current.isError) MaterialTheme.colorScheme.onErrorContainer
      else MaterialTheme.colorScheme.onPrimaryContainer

    Surface(
      color = containerColor,
      contentColor = contentColor,
      shape = MaterialTheme.shapes.medium,
      tonalElevation = 3.dp,
      modifier =
        Modifier.fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .testTag("feedback_banner"),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      ) {
        Icon(
          imageVector = if (current.isError) Icons.Filled.Info else Icons.Filled.CheckCircle,
          contentDescription = if (current.isError) "Alerta de erro" else "Confirmação",
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = current.message,
          style = MaterialTheme.typography.bodyMedium,
          modifier = Modifier.weight(1f),
        )
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.size(48.dp).testTag("dismiss_feedback_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Fechar mensagem",
          )
        }
      }
    }
  }
}

@Composable
fun InteractiveRouteMapCard(
  originAddress: String,
  destinationAddress: String,
  originLat: Double,
  originLng: Double,
  destLat: Double,
  destLng: Double,
  distanceKm: Double,
  priceCents: Long,
  onMapError: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val isMapsConfigured = LocationAndMapsHelper.isGoogleMapsKeyConfigured
  val primaryColor = MaterialTheme.colorScheme.primary
  val tertiaryColor = MaterialTheme.colorScheme.tertiary
  val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.28f)
  val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant

  Card(
    shape = MaterialTheme.shapes.large,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier.fillMaxWidth().testTag("route_map_card"),
  ) {
    Column {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(190.dp)
            .background(surfaceVariant),
      ) {
        if (isMapsConfigured) {
          val originLatLng = remember(originLat, originLng) { LatLng(originLat, originLng) }
          val destLatLng = remember(destLat, destLng) { LatLng(destLat, destLng) }
          val midLatLng =
            remember(originLatLng, destLatLng) {
              LatLng(
                (originLatLng.latitude + destLatLng.latitude) / 2.0,
                (originLatLng.longitude + destLatLng.longitude) / 2.0,
              )
            }
          val cameraPositionState =
            rememberCameraPositionState(key = "${originLat}_${destLat}") {
              position = CameraPosition.fromLatLngZoom(midLatLng, 13.5f)
            }

          GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
          ) {
            Marker(
              state = remember(originLatLng) { MarkerState(position = originLatLng) },
              title = "Origem",
              snippet = originAddress.ifBlank { "Ponto de partida" },
            )
            Marker(
              state = remember(destLatLng) { MarkerState(position = destLatLng) },
              title = "Destino",
              snippet = destinationAddress.ifBlank { "Ponto de chegada" },
            )
            Polyline(
              points = listOf(originLatLng, destLatLng),
              color = primaryColor,
              width = 12f,
            )
          }
        } else {
          // Schematic urban route preview when GOOGLE_MAPS_API_KEY is not yet configured in Secrets
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cols = 8
            val rows = 5
            for (c in 1 until cols) {
              val x = (w / cols) * c
              drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1.5f,
              )
            }
            for (r in 1 until rows) {
              val y = (h / rows) * r
              drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1.5f,
              )
            }

            val startPt = Offset(w * 0.18f, h * 0.72f)
            val endPt = Offset(w * 0.82f, h * 0.28f)
            val routePath =
              Path().apply {
                moveTo(startPt.x, startPt.y)
                cubicTo(
                  w * 0.42f,
                  h * 0.76f,
                  w * 0.56f,
                  h * 0.24f,
                  endPt.x,
                  endPt.y,
                )
              }

            drawPath(
              path = routePath,
              color = primaryColor.copy(alpha = 0.22f),
              style = Stroke(width = 18f, cap = StrokeCap.Round),
            )
            drawPath(
              path = routePath,
              color = primaryColor,
              style =
                Stroke(
                  width = 7f,
                  cap = StrokeCap.Round,
                  pathEffect = PathEffect.dashPathEffect(floatArrayOf(22f, 12f), 0f),
                ),
            )

            drawCircle(color = primaryColor.copy(alpha = 0.25f), radius = 22f, center = startPt)
            drawCircle(color = primaryColor, radius = 10f, center = startPt)
            drawCircle(color = tertiaryColor.copy(alpha = 0.25f), radius = 22f, center = endPt)
            drawCircle(color = tertiaryColor, radius = 10f, center = endPt)
          }

          Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
            shape = MaterialTheme.shapes.small,
            modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Map,
                contentDescription = "Status do Google Maps",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Prévia de rota • Configure GOOGLE_MAPS_API_KEY p/ mapa nativo",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }

        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer,
          contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
          shape = MaterialTheme.shapes.medium,
          modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
        ) {
          Text(
            text =
              String.format(
                java.util.Locale.forLanguageTag("pt-BR"),
                "%.1f km • %s",
                distanceKm,
                FareCalculator.formatCurrencyBrl(priceCents),
              ),
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          )
        }
      }

      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(16.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.LocationOn,
            contentDescription = "Origem",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = originAddress.ifBlank { "Informe o endereço de origem" },
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.Flag,
            contentDescription = "Destino",
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = destinationAddress.ifBlank { "Informe o endereço de destino" },
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        if (originAddress.length >= 3 && destinationAddress.length >= 3) {
          OutlinedButton(
            onClick = {
              LocationAndMapsHelper.openExternalGoogleMapsRoute(
                context = context,
                originAddress = originAddress,
                destinationAddress = destinationAddress,
                onError = onMapError,
              )
            },
            modifier = Modifier.fillMaxWidth().testTag("open_external_maps_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.TwoWheeler,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = stringResource(R.string.open_google_maps_button))
          }
        }
      }
    }
  }
}

@Composable
fun OrderStatusStepper(
  currentStatus: OrderStatus,
  modifier: Modifier = Modifier,
) {
  val steps =
    listOf(
      OrderStatus.SOLICITADO to "Solicitado",
      OrderStatus.ACEITO to "Aceito",
      OrderStatus.A_CAMINHO to "A caminho",
      OrderStatus.EM_ANDAMENTO to "Em andamento",
      OrderStatus.CONCLUIDO to "Concluído",
    )

  if (currentStatus == OrderStatus.CANCELADO) {
    Surface(
      color = MaterialTheme.colorScheme.errorContainer,
      contentColor = MaterialTheme.colorScheme.onErrorContainer,
      shape = MaterialTheme.shapes.medium,
      modifier = modifier.fillMaxWidth(),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(14.dp),
      ) {
        Icon(imageVector = Icons.Filled.Cancel, contentDescription = "Cancelado")
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "Este pedido foi cancelado antes do início do atendimento.",
          style = MaterialTheme.typography.bodyMedium,
        )
      }
    }
    return
  }

  Column(
    verticalArrangement = Arrangement.spacedBy(8.dp),
    modifier = modifier.fillMaxWidth().testTag("order_status_stepper"),
  ) {
    steps.forEach { (stepStatus, label) ->
      val reached = currentStatus.stepIndex >= stepStatus.stepIndex
      val isCurrent = currentStatus == stepStatus
      val dotColor =
        when {
          isCurrent -> MaterialTheme.colorScheme.primary
          reached -> MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
          else -> MaterialTheme.colorScheme.outline
        }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier =
            Modifier.size(26.dp)
              .clip(CircleShape)
              .background(
                if (reached) dotColor else MaterialTheme.colorScheme.surfaceVariant
              ),
        ) {
          Icon(
            imageVector = if (reached) Icons.Filled.CheckCircle else Icons.Filled.Schedule,
            contentDescription = label,
            tint =
              if (reached) MaterialTheme.colorScheme.onPrimary
              else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp),
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
          text = label,
          style =
            if (isCurrent) MaterialTheme.typography.titleSmall
            else MaterialTheme.typography.bodyMedium,
          fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
          color =
            if (reached) MaterialTheme.colorScheme.onSurface
            else MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.weight(1f),
        )
        if (isCurrent) {
          AssistChip(
            onClick = {},
            label = { Text("Atual", style = MaterialTheme.typography.labelSmall) },
          )
        }
      }
    }
  }
}

@Composable
fun IntegrationStatusDialog(onDismiss: () -> Unit) {
  BackHandler(onBack = onDismiss)
  val context = LocalContext.current
  val mapsReady = LocationAndMapsHelper.isGoogleMapsKeyConfigured
  val paymentReady = PaymentGatewayService.isProviderKeyConfigured
  val firebaseProjectId =
    remember {
      runCatching { FirebaseApp.getInstance().options.projectId.orEmpty() }.getOrDefault("")
    }
  val firestoreDbId = remember(context) { context.getString(R.string.firestore_database_id) }
  val googleClientReady =
    remember(context) {
      runCatching { context.getString(R.string.default_web_client_id).isNotBlank() }
        .getOrDefault(false)
    }
  val activeEmail =
    remember {
      runCatching { Firebase.auth.currentUser?.email.orEmpty() }.getOrDefault("")
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Status das Integrações e Conexão Firebase") },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.verticalScroll(rememberScrollState()),
      ) {
        Text(
          text = "Conexão Firebase verificada em tempo de execução:",
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.primary,
        )
      Text(
        text =
          "• Projeto Firebase: ${firebaseProjectId.ifBlank { "Conectado" }}\n" +
            "• Banco Cloud Firestore: $firestoreDbId\n" +
            "• Google Sign-In OAuth Client: ${if (googleClientReady) "Configurado e ativo" else "Ausente"}\n" +
            "• Sessão atual: ${activeEmail.ifBlank { "Sessão interativa local (sem conta Google conectada)" }}",
        style = MaterialTheme.typography.bodySmall,
      )
      HorizontalDivider()
      Text(
        text = "Recursos 100% funcionais agora:",
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
      )
      Text(
        text =
          "• Botões Passageiro e Motorista na tela inicial com navegação e botão Voltar\n" +
            "• Formulários completos de Corrida de Moto e Entrega de Pacotes\n" +
            "• Painel do Motorista com status Online/Offline, aceite/recusa e avanço de etapas\n" +
            "• Login com Google (Firebase Auth + Credential Manager) e banco Cloud Firestore\n" +
            "• Regras de segurança Zero-Trust implantadas no Firestore\n" +
            "• GPS nativo para preenchimento da origem e abertura no Google Maps",
        style = MaterialTheme.typography.bodySmall,
      )
      HorizontalDivider()
      Text(
        text = "Integrações preparadas para configuração (painel Secrets):",
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.tertiary,
      )
      Text(
        text =
          "• GOOGLE_MAPS_API_KEY: ${if (mapsReady) "Configurada (mapa nativo ativo)" else "Pendente (exibindo rota esquemática + botão Google Maps)"}\n" +
            "• PAYMENT_PROVIDER_PUBLIC_KEY: ${if (paymentReady) "Chave detectada" else "Pendente (Pix e Cartão preparados sem simular cobrança falsa)"}",
        style = MaterialTheme.typography.bodySmall,
      )
      HorizontalDivider()
      Text(
        text = "Como testar na pré-visualização ou entre 2 usuários:",
        style = MaterialTheme.typography.titleSmall,
      )
      Text(
        text =
          "1. Na tela inicial, toque em Passageiro e solicite uma corrida ou entrega.\n" +
            "2. Toque no botão Voltar (seta no topo), abra Motorista, toque em Ficar Online e aceite o pedido!\n" +
            "3. Para sincronizar em tempo real entre 2 celulares via Firebase, conecte contas Google nos dois aparelhos.",
        style = MaterialTheme.typography.bodySmall,
      )
    }
  },
  confirmButton = {
    TextButton(
      onClick = onDismiss,
      modifier = Modifier.testTag("close_integrations_dialog_button"),
    ) {
      Text("Entendi")
    }
  },
)
}

@Composable
fun GoogleAuthStatusDialog(
  message: String,
  onDismiss: () -> Unit,
  onOpenPassenger: (() -> Unit)? = null,
  onOpenDriver: (() -> Unit)? = null,
) {
  BackHandler(onBack = onDismiss)
  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("google_auth_feedback_dialog"),
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Info,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = stringResource(R.string.google_auth_dialog_title))
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
          text = message,
          style = MaterialTheme.typography.bodyMedium,
        )
        if (onOpenPassenger != null || onOpenDriver != null) {
          HorizontalDivider()
          Text(
            text = "Acesso rápido às telas funcionais:",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
          )
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            if (onOpenPassenger != null) {
              OutlinedButton(
                onClick = {
                  onDismiss()
                  onOpenPassenger()
                },
                modifier = Modifier.weight(1f).testTag("dialog_open_passenger_button"),
              ) {
                Text("Passageiro")
              }
            }
            if (onOpenDriver != null) {
              OutlinedButton(
                onClick = {
                  onDismiss()
                  onOpenDriver()
                },
                modifier = Modifier.weight(1f).testTag("dialog_open_driver_button"),
              ) {
                Text("Motorista")
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("close_google_auth_dialog_button"),
      ) {
        Text("Entendi")
      }
    },
  )
}

@Composable
fun LocalSessionCloudBanner(
  isSigningIn: Boolean,
  onConnectGoogleClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.75f),
    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    shape = MaterialTheme.shapes.medium,
    modifier =
      modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp)
        .testTag("local_session_cloud_banner"),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
      Text(
        text = stringResource(R.string.local_preview_banner_text),
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.weight(1f),
      )
      Spacer(modifier = Modifier.width(8.dp))
      TextButton(
        onClick = onConnectGoogleClick,
        enabled = !isSigningIn,
        modifier = Modifier.testTag("cloud_sync_sign_in_button"),
      ) {
        Text(
          text =
            if (isSigningIn) "Conectando…"
            else stringResource(R.string.local_preview_connect_button),
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
        )
      }
    }
  }
}
