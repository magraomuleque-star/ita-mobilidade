package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.auth.signInWithGoogleInteractive
import com.example.data.model.AccountMode
import com.example.data.model.DriverProfile
import com.example.data.model.FareCalculator
import com.example.data.model.OrderStatus
import com.example.data.model.ServiceOrder
import com.example.data.model.ServiceType
import com.example.ui.components.GoogleAuthStatusDialog
import com.example.ui.components.IntegrationStatusDialog
import com.example.ui.components.InteractiveRouteMapCard
import com.example.ui.components.LocalSessionCloudBanner
import com.example.ui.components.OrderStatusStepper
import com.example.ui.components.ProfileAndModeDialog
import com.example.ui.components.TopFeedbackBar
import com.example.ui.viewmodel.FeedbackBanner
import com.example.ui.viewmodel.MobilityViewModel
import com.example.ui.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriverHomeScreen(
  profile: DriverProfile,
  hasPassengerProfile: Boolean,
  incomingOrdersState: UiState<List<ServiceOrder>>,
  assignedOrdersState: UiState<List<ServiceOrder>>,
  isBusy: Boolean,
  feedback: FeedbackBanner?,
  viewModel: MobilityViewModel,
  onNavigateBack: () -> Unit,
  onSwitchToPassengerMode: () -> Unit,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  var selectedTab by rememberSaveable { mutableIntStateOf(0) }
  var showIntegrationsDialog by rememberSaveable { mutableStateOf(false) }
  var showProfileDialog by rememberSaveable { mutableStateOf(false) }
  var isSigningInCloud by remember { mutableStateOf(false) }
  var googleAuthDialogMessage by rememberSaveable { mutableStateOf<String?>(null) }

  BackHandler {
    if (selectedTab != 0) {
      selectedTab = 0
    } else {
      onNavigateBack()
    }
  }

  val incomingList = (incomingOrdersState as? UiState.Success)?.data.orEmpty()
  val assignedList = (assignedOrdersState as? UiState.Success)?.data.orEmpty()
  val activeOrder = remember(assignedList) { assignedList.firstOrNull { it.typedStatus.isActive } }

  if (googleAuthDialogMessage != null) {
    GoogleAuthStatusDialog(
      message = googleAuthDialogMessage.orEmpty(),
      onDismiss = { googleAuthDialogMessage = null },
    )
  }

  if (showIntegrationsDialog) {
    IntegrationStatusDialog(onDismiss = { showIntegrationsDialog = false })
  }

  if (showProfileDialog) {
    ProfileAndModeDialog(
      currentMode = AccountMode.MOTORISTA,
      passengerProfile = null,
      driverProfile = profile,
      hasOtherProfile = hasPassengerProfile,
      isBusy = isBusy,
      isCloudSynced = viewModel.isCloudSynced,
      onSavePassenger = { _, _ -> },
      onSaveDriver = { name, phone, model, plate ->
        viewModel.updateDriverProfile(
          fullName = name,
          phone = phone,
          vehicleModel = model,
          vehiclePlate = plate,
          onSaved = { showProfileDialog = false },
        )
      },
      onSwitchOrActivateOtherMode = {
        onSwitchToPassengerMode()
        viewModel.switchOrActivateMode(
          targetMode = AccountMode.PASSAGEIRO,
          hasTargetProfile = hasPassengerProfile,
        )
      },
      onDismiss = { showProfileDialog = false },
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize().testTag("driver_home_screen")) {
    val isExpanded = maxWidth >= 700.dp

    Scaffold(
      contentWindowInsets = WindowInsets.safeDrawing,
      topBar = {
        TopAppBar(
          navigationIcon = {
            IconButton(
              onClick = onNavigateBack,
              modifier = Modifier.testTag("navigate_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.navigate_back_action),
              )
            }
          },
          title = {
            Column {
              Text(text = stringResource(R.string.app_name))
              Text(
                text =
                  "Modo Motorista • ${profile.vehicleModel} (${profile.vehiclePlate})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          },
          actions = {
            IconButton(
              onClick = { showProfileDialog = true },
              modifier = Modifier.testTag("driver_profile_mode_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.AccountCircle,
                contentDescription = stringResource(R.string.nav_profile_and_mode),
              )
            }
            IconButton(
              onClick = { showIntegrationsDialog = true },
              modifier = Modifier.testTag("driver_integrations_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Info,
                contentDescription = stringResource(R.string.nav_integrations_info),
              )
            }
            if (viewModel.isCloudSynced) {
              IconButton(
                onClick = onSignOut,
                modifier = Modifier.testTag("driver_sign_out_button"),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Logout,
                  contentDescription = stringResource(R.string.sign_out_action),
                )
              }
            }
          },
        )
      },
      bottomBar = {
        if (!isExpanded) {
          NavigationBar {
            NavigationBarItem(
              selected = selectedTab == 0,
              onClick = { selectedTab = 0 },
              icon = {
                BadgedBox(
                  badge = {
                    if (profile.online && incomingList.isNotEmpty()) {
                      Badge { Text("${incomingList.size}") }
                    }
                  }
                ) {
                  Icon(
                    imageVector = Icons.Filled.TwoWheeler,
                    contentDescription = stringResource(R.string.nav_driver_radar),
                  )
                }
              },
              label = { Text(stringResource(R.string.nav_driver_radar)) },
              modifier = Modifier.testTag("driver_tab_radar"),
            )
            NavigationBarItem(
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              icon = {
                BadgedBox(
                  badge = {
                    if (activeOrder != null) {
                      Badge { Text("1") }
                    }
                  }
                ) {
                  Icon(
                    imageVector = Icons.Filled.Schedule,
                    contentDescription = stringResource(R.string.nav_driver_active),
                  )
                }
              },
              label = { Text(stringResource(R.string.nav_driver_active)) },
              modifier = Modifier.testTag("driver_tab_active"),
            )
            NavigationBarItem(
              selected = selectedTab == 2,
              onClick = { selectedTab = 2 },
              icon = {
                Icon(
                  imageVector = Icons.Filled.AccountBalanceWallet,
                  contentDescription = stringResource(R.string.nav_driver_earnings),
                )
              },
              label = { Text(stringResource(R.string.nav_driver_earnings)) },
              modifier = Modifier.testTag("driver_tab_earnings"),
            )
          }
        }
      },
    ) { innerPadding ->
      Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        if (isExpanded) {
          NavigationRail(modifier = Modifier.fillMaxHeight()) {
            NavigationRailItem(
              selected = selectedTab == 0,
              onClick = { selectedTab = 0 },
              icon = { Icon(Icons.Filled.TwoWheeler, contentDescription = null) },
              label = { Text(stringResource(R.string.nav_driver_radar)) },
            )
            NavigationRailItem(
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              icon = { Icon(Icons.Filled.Schedule, contentDescription = null) },
              label = { Text(stringResource(R.string.nav_driver_active)) },
            )
            NavigationRailItem(
              selected = selectedTab == 2,
              onClick = { selectedTab = 2 },
              icon = { Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null) },
              label = { Text(stringResource(R.string.nav_driver_earnings)) },
            )
          }
        }

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        ) {
          if (!viewModel.isCloudSynced && feedback == null) {
            LocalSessionCloudBanner(
              isSigningIn = isSigningInCloud,
              onConnectGoogleClick = {
                isSigningInCloud = true
                signInWithGoogleInteractive(
                  context = context,
                  credentialManager = credentialManager,
                  scope = scope,
                  onAuthSuccess = { isSigningInCloud = false },
                  onAuthError = { msg ->
                    isSigningInCloud = false
                    googleAuthDialogMessage = msg
                  },
                  onAuthCancelled = {
                    isSigningInCloud = false
                    googleAuthDialogMessage =
                      "O seletor de contas do Google foi fechado ou não há conta Google conectada neste emulador. Você pode continuar usando o Modo Motorista normalmente nesta sessão."
                  },
                )
              },
              modifier = Modifier.widthIn(max = 680.dp),
            )
          }

          TopFeedbackBar(
            feedback = feedback,
            onDismiss = viewModel::clearFeedback,
            modifier = Modifier.widthIn(max = 680.dp),
          )

          // Online / Offline Status Header
          DriverOnlineControlBanner(
            online = profile.online,
            isBusy = isBusy,
            onToggleOnline = viewModel::toggleDriverOnline,
            modifier =
              Modifier.widthIn(max = 680.dp)
                .padding(horizontal = 16.dp, vertical = 6.dp),
          )

          Box(modifier = Modifier.fillMaxSize().widthIn(max = 680.dp)) {
            when (selectedTab) {
              0 ->
                DriverRadarTab(
                  profile = profile,
                  incomingOrdersState = incomingOrdersState,
                  activeOrder = activeOrder,
                  isBusy = isBusy,
                  onAcceptOrder = { orderId ->
                    viewModel.acceptOrder(
                      orderId = orderId,
                      driverProfile = profile,
                      onAcceptedSuccess = { selectedTab = 1 },
                    )
                  },
                  onDeclineOrder = viewModel::declineOrder,
                  onGoOnline = { viewModel.toggleDriverOnline(true) },
                  onGoToActiveOrder = { selectedTab = 1 },
                )
              1 ->
                DriverActiveServiceTab(
                  activeOrder = activeOrder,
                  isBusy = isBusy,
                  onAdvanceStatus = viewModel::advanceOrderStatus,
                  onShowMapError = { msg -> viewModel.showMessage(msg, isError = true) },
                  onBackToRadar = { selectedTab = 0 },
                )
              else ->
                DriverEarningsAndHistoryTab(
                  assignedOrdersState = assignedOrdersState,
                )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DriverOnlineControlBanner(
  online: Boolean,
  isBusy: Boolean,
  onToggleOnline: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
) {
  val containerColor =
    if (online) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.surfaceVariant
  val contentColor =
    if (online) MaterialTheme.colorScheme.onPrimaryContainer
    else MaterialTheme.colorScheme.onSurfaceVariant

  Card(
    colors = CardDefaults.cardColors(containerColor = containerColor, contentColor = contentColor),
    shape = MaterialTheme.shapes.large,
    modifier = modifier.fillMaxWidth().testTag("driver_online_banner"),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Icon(
          imageVector = Icons.Filled.PowerSettingsNew,
          contentDescription = null,
          modifier = Modifier.size(26.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text =
              if (online) stringResource(R.string.driver_online_title)
              else stringResource(R.string.driver_offline_title),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text =
              if (online) stringResource(R.string.driver_online_desc)
              else stringResource(R.string.driver_offline_desc),
            style = MaterialTheme.typography.bodySmall,
          )
        }
      }

      Switch(
        checked = online,
        onCheckedChange = { onToggleOnline(it) },
        enabled = !isBusy,
        modifier = Modifier.testTag("driver_online_switch"),
      )
    }
  }
}

@Composable
private fun DriverRadarTab(
  profile: DriverProfile,
  incomingOrdersState: UiState<List<ServiceOrder>>,
  activeOrder: ServiceOrder?,
  isBusy: Boolean,
  onAcceptOrder: (String) -> Unit,
  onDeclineOrder: (String) -> Unit,
  onGoOnline: () -> Unit,
  onGoToActiveOrder: () -> Unit,
) {
  if (!profile.online) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.fillMaxSize().padding(32.dp),
    ) {
      Icon(
        imageVector = Icons.Filled.PowerSettingsNew,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(56.dp),
      )
      Spacer(modifier = Modifier.height(12.dp))
      Text(
        text = "Você está offline no momento",
        style = MaterialTheme.typography.titleLarge,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Toque no botão abaixo para ficar online e começar a receber corridas de moto e entregas em tempo real.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(modifier = Modifier.height(20.dp))
      Button(
        onClick = onGoOnline,
        enabled = !isBusy,
        modifier = Modifier.height(50.dp).testTag("driver_go_online_cta"),
      ) {
        Text(stringResource(R.string.driver_go_online))
      }
    }
    return
  }

  Column(modifier = Modifier.fillMaxSize()) {
    if (activeOrder != null) {
      Card(
        colors =
          CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier =
          Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth().padding(14.dp),
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Serviço em andamento (${activeOrder.typedStatus.labelPtBr})",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Text(
              text = "Conclua o atendimento atual antes de aceitar um novo chamado.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
          }
          OutlinedButton(
            onClick = onGoToActiveOrder,
            modifier = Modifier.testTag("go_to_active_service_button"),
          ) {
            Text("Abrir")
          }
        }
      }
    }

    when (incomingOrdersState) {
      is UiState.Loading -> {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
          CircularProgressIndicator()
        }
      }
      is UiState.Error -> {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(24.dp)) {
          Text(text = incomingOrdersState.message, color = MaterialTheme.colorScheme.error)
        }
      }
      is UiState.Success -> {
        if (incomingOrdersState.data.isEmpty()) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize().padding(32.dp),
          ) {
            CircularProgressIndicator(strokeWidth = 2.5.dp, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
              text = stringResource(R.string.empty_driver_queue_title),
              style = MaterialTheme.typography.titleLarge,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = stringResource(R.string.empty_driver_queue_desc),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        } else {
          LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize().testTag("driver_incoming_orders_list"),
          ) {
            items(incomingOrdersState.data, key = { it.id }) { order ->
              IncomingOrderOfferCard(
                order = order,
                canAccept = !isBusy && activeOrder == null,
                isBusy = isBusy,
                onAccept = { onAcceptOrder(order.id) },
                onDecline = { onDeclineOrder(order.id) },
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun IncomingOrderOfferCard(
  order: ServiceOrder,
  canAccept: Boolean,
  isBusy: Boolean,
  onAccept: () -> Unit,
  onDecline: () -> Unit,
) {
  Card(
    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    shape = MaterialTheme.shapes.large,
    modifier = Modifier.fillMaxWidth().testTag("incoming_order_card_${order.id}"),
  ) {
    Column(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.padding(16.dp),
    ) {
      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Surface(
          color =
            if (order.typedService == ServiceType.CORRIDA_MOTO) {
              MaterialTheme.colorScheme.primaryContainer
            } else {
              MaterialTheme.colorScheme.tertiaryContainer
            },
          shape = MaterialTheme.shapes.small,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
          ) {
            Icon(
              imageVector =
                if (order.typedService == ServiceType.CORRIDA_MOTO) Icons.Filled.TwoWheeler
                else Icons.Filled.LocalShipping,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = order.typedService.labelPtBr,
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = FareCalculator.formatCurrencyBrl(order.priceCents),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text =
              String.format(
                java.util.Locale.forLanguageTag("pt-BR"),
                "%.1f km • %s",
                order.estimatedDistanceKm,
                order.typedPaymentMethod.labelPtBr,
              ),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      Text(
        text = "Solicitante: ${order.passengerName}",
        style = MaterialTheme.typography.titleSmall,
      )

      if (order.typedService == ServiceType.ENTREGA_PACOTE) {
        Text(
          text =
            "Volume: ${order.packageDescription}" +
              if (order.recipientName.isNotBlank()) " • Entregar para: ${order.recipientName}" else "",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.tertiary,
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.LocationOn,
          contentDescription = "Origem",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = order.originAddress, style = MaterialTheme.typography.bodyMedium)
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Flag,
          contentDescription = "Destino",
          tint = MaterialTheme.colorScheme.tertiary,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = order.destinationAddress, style = MaterialTheme.typography.bodyMedium)
      }

      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
      ) {
        OutlinedButton(
          onClick = onDecline,
          enabled = !isBusy,
          modifier =
            Modifier.weight(1f)
              .height(48.dp)
              .testTag("decline_order_button_${order.id}"),
        ) {
          Text(stringResource(R.string.driver_decline_button))
        }
        Button(
          onClick = onAccept,
          enabled = canAccept,
          modifier =
            Modifier.weight(1.4f)
              .height(48.dp)
              .testTag("accept_order_button_${order.id}"),
        ) {
          Text(stringResource(R.string.driver_accept_button))
        }
      }
    }
  }
}

@Composable
private fun DriverActiveServiceTab(
  activeOrder: ServiceOrder?,
  isBusy: Boolean,
  onAdvanceStatus: (String, OrderStatus) -> Unit,
  onShowMapError: (String) -> Unit,
  onBackToRadar: () -> Unit,
) {
  if (activeOrder == null) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.fillMaxSize().padding(32.dp),
    ) {
      Icon(
        imageVector = Icons.Filled.TwoWheeler,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(52.dp),
      )
      Spacer(modifier = Modifier.height(12.dp))
      Text(
        text = "Nenhum serviço em execução",
        style = MaterialTheme.typography.titleLarge,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Aceite um chamado na aba Chamados para gerenciar a corrida ou entrega aqui.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(modifier = Modifier.height(18.dp))
      OutlinedButton(
        onClick = onBackToRadar,
        modifier = Modifier.testTag("empty_driver_active_back_button"),
      ) {
        Text("Ver chamados disponíveis")
      }
    }
    return
  }

  val nextAction: Pair<OrderStatus, String>? =
    when (activeOrder.typedStatus) {
      OrderStatus.ACEITO ->
        OrderStatus.A_CAMINHO to stringResource(R.string.driver_status_to_en_route)
      OrderStatus.A_CAMINHO ->
        OrderStatus.EM_ANDAMENTO to stringResource(R.string.driver_status_to_in_progress)
      OrderStatus.EM_ANDAMENTO ->
        OrderStatus.CONCLUIDO to stringResource(R.string.driver_status_to_completed)
      else -> null
    }

  Column(
    verticalArrangement = Arrangement.spacedBy(16.dp),
    modifier =
      Modifier.fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
  ) {
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.padding(16.dp),
      ) {
        Row(
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column {
            Text(
              text = activeOrder.typedService.labelPtBr,
              style = MaterialTheme.typography.titleLarge,
            )
            Text(
              text = "Passageiro: ${activeOrder.passengerName}",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Text(
            text = FareCalculator.formatCurrencyBrl(activeOrder.priceCents),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
          )
        }

        if (activeOrder.typedService == ServiceType.ENTREGA_PACOTE) {
          Surface(
            color = MaterialTheme.colorScheme.tertiaryContainer,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text =
                "Pacote: ${activeOrder.packageDescription}" +
                  if (activeOrder.recipientName.isNotBlank()) {
                    "\nDestinatário: ${activeOrder.recipientName}"
                  } else {
                    ""
                  },
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onTertiaryContainer,
              modifier = Modifier.padding(12.dp),
            )
          }
        }

        Text(
          text =
            "Pagamento selecionado: ${activeOrder.typedPaymentMethod.labelPtBr} • ${activeOrder.typedPaymentStatus.labelPtBr}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        HorizontalDivider()
        OrderStatusStepper(currentStatus = activeOrder.typedStatus)
      }
    }

    if (nextAction != null) {
      Button(
        onClick = { onAdvanceStatus(activeOrder.id, nextAction.first) },
        enabled = !isBusy,
        modifier =
          Modifier.fillMaxWidth()
            .height(56.dp)
            .testTag("driver_advance_status_button"),
      ) {
        Icon(
          imageVector =
            if (nextAction.first == OrderStatus.CONCLUIDO) Icons.Filled.CheckCircle
            else Icons.Filled.PlayArrow,
          contentDescription = null,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = nextAction.second, style = MaterialTheme.typography.titleMedium)
      }
    }

    InteractiveRouteMapCard(
      originAddress = activeOrder.originAddress,
      destinationAddress = activeOrder.destinationAddress,
      originLat = activeOrder.originLat,
      originLng = activeOrder.originLng,
      destLat = activeOrder.destLat,
      destLng = activeOrder.destLng,
      distanceKm = activeOrder.estimatedDistanceKm,
      priceCents = activeOrder.priceCents,
      onMapError = onShowMapError,
    )
  }
}

@Composable
private fun DriverEarningsAndHistoryTab(
  assignedOrdersState: UiState<List<ServiceOrder>>,
) {
  when (assignedOrdersState) {
    is UiState.Loading -> {
      Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        CircularProgressIndicator()
      }
    }
    is UiState.Error -> {
      Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Text(text = assignedOrdersState.message, color = MaterialTheme.colorScheme.error)
      }
    }
    is UiState.Success -> {
      val completedOrders =
        remember(assignedOrdersState.data) {
          assignedOrdersState.data.filter { it.typedStatus == OrderStatus.CONCLUIDO }
        }
      val totalEarningsCents =
        remember(completedOrders) { completedOrders.sumOf { it.priceCents } }
      val rideCount =
        remember(completedOrders) {
          completedOrders.count { it.typedService == ServiceType.CORRIDA_MOTO }
        }
      val deliveryCount =
        remember(completedOrders) {
          completedOrders.count { it.typedService == ServiceType.ENTREGA_PACOTE }
        }

      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize().testTag("driver_earnings_list"),
      ) {
        item {
          Card(
            colors =
              CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = MaterialTheme.shapes.extraLarge,
            modifier = Modifier.fillMaxWidth().testTag("driver_earnings_summary_card"),
          ) {
            Column(
              verticalArrangement = Arrangement.spacedBy(10.dp),
              modifier = Modifier.padding(20.dp),
            ) {
              Text(
                text = stringResource(R.string.earnings_total_label),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
              Text(
                text = FareCalculator.formatCurrencyBrl(totalEarningsCents),
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
              HorizontalDivider(
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f)
              )
              Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Text(
                  text = "${stringResource(R.string.earnings_completed_count)}: ${completedOrders.size}",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                  text = "$rideCount corridas • $deliveryCount entregas",
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
              }
            }
          }
        }

        if (assignedOrdersState.data.isEmpty()) {
          item {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
            ) {
              Text(
                text = stringResource(R.string.empty_driver_history_title),
                style = MaterialTheme.typography.titleMedium,
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = stringResource(R.string.empty_driver_history_desc),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        } else {
          items(assignedOrdersState.data, key = { it.id }) { order ->
            OrderHistoryCard(order = order, showDriverInfo = false)
          }
        }
      }
    }
  }
}
